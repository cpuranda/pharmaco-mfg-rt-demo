# Session handoff — Novartis Finance Genie PoC, Novartis DEV (state at 2026-11-05)

Resume the Claude Code session that built this package:
`cd ~ && claude --resume d0b8b906-c24d-4d79-a062-c09c6e71e490`
or start a new session from `~` and say:
*"Read ~/code/novartis-finance-genie-poc-dev/docs/SESSION_HANDOFF.md and continue the Novartis DEV Finance Genie PoC."*

## State
* Package v0.4.3 in `~/code/novartis-finance-genie-poc-dev`, a git repo pushed to https://github.com/cpuranda/fin-gen-poc (PUBLIC, branch main; user chose to publish as-is on 2026-11-03). Backups in `~/code/backups/`. Upload folder `~/Downloads/finance_genie_dev_UPLOAD_v0.4.3/`. Demo pinned to the October 2026 data copy: `semantics.as_of_date = 2026-10-31` (window 1–31 Oct; Genie instructed not to add date filters). Set a new date, or `null`, only after re-copying the tables.
* Demo Script & Deployment Guide (Google Doc): https://docs.google.com/document/d/1BL-UUlPaRi0VdfU8Bf4ZgzA_dMR1mtIMSWzCnofMdVI/edit, source `docs/DEV_DEMO_SCRIPT.md`.
* Nothing executed in Novartis DEV by Claude (no access); the user deploys via the workspace UI with the generated notebooks.
* Config `config/novartis_dev.json`: source = target = `f1common_eu_platform.chandra_fin_genie_poc` (copied `lb_*_history` tables), warehouse name `DBSQL_89973`, 4 users by 521 login ID (Novartis DEV grants access by 521 ID, not novartis.com e-mail; changed 2026-11-04): PURANCH1 → ALVARVI6, MUTAFMI1 → AGARWVAC, KOLLISA4 → ABADFR1, MOHDHA1 → ABESH7 (all `@novartis.net`), `usage_grants_by = platform_team`, `preflight_confirmed = false`.

## Typical follow-ups
* Preflight results differ (P0 login string, P3 non-zero, R8 flag values, R4 hierarchy names, R12 user checks): edit `config/novartis_dev.json` → `python3 scripts/render.py novartis_dev --pending-preflight` (or final render after setting `preflight_confirmed: true`) → `uv run pytest` → rebuild the upload folder.
* Demo Script changes: edit `docs/DEV_DEMO_SCRIPT.md` and update the same Google Doc (keep its URL); fill section 8 from notebook 05 results.

## Rules
* Never write `lb_*` tables from the package (render.py guard); only `src_cur_` / `sec_` / `mv_` objects in the PoC schema.
* No App, no service principals; identity only from `current_user()`; Genie space source = Metric View only.
* USE CATALOG / USE SCHEMA are granted by the Novartis platform team (`PLATFORM_TEAM_GRANTS.sql`), not by the notebooks.
* `CREATE OR REPLACE VIEW` drops grants → re-run notebook 04 after re-running 02.
