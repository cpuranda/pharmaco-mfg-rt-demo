-- 1. lb_config_t_md_page_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_config_t_md_page_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  page_id STRING,
  section_id STRING,
  page_name STRING,
  sort_order STRING,
  data_source_name STRING,
  is_active STRING,
  is_web_active STRING,
  is_default STRING,
  is_web_default STRING,
  is_watchlist_item_based STRING,
  watchlist_item_account_hierarchy_name STRING,
  about_page STRING,
  about_page_web STRING,
  file_path STRING,
  is_external STRING,
  url STRING,
  web_app_url STRING,
  has_graph STRING,
  graph_url STRING,
  has_drillthrough STRING,
  drillthrough_url STRING,
  quarter_view_url STRING,
  json_dataformat STRING,
  has_time_filter_sync STRING,
  has_currency_filter_sync STRING,
  has_biometric_auth STRING,
  has_banner STRING,
  last_updated_tmstmp TIMESTAMP,
  audit_created_tmstmp TIMESTAMP,
  audit_updated_tmstmp TIMESTAMP,
  loading_title STRING)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 2. lb_config_t_md_user_settings_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_config_t_md_user_settings_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  userid STRING NOT NULL,
  keyuser STRING,
  setting_id STRING,
  setting_name STRING,
  setting_desc STRING,
  is_active STRING,
  is_enabled STRING,
  is_visible STRING,
  setting_group_id STRING,
  setting_group_is_default STRING,
  setting_json STRING,
  audit_created_tmstmp TIMESTAMP,
  audit_updated_tmstmp TIMESTAMP,
  value_text STRING,
  value_numeric STRING,
  sort_order STRING)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 3. lb_t_dtm_daily_sales_report_drill_down_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_t_dtm_daily_sales_report_drill_down_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  measure_id DECIMAL(38,0),
  reporting_date DATE,
  account STRING,
  business_unit STRING,
  entity STRING,
  brand STRING,
  value FLOAT,
  numerator FLOAT,
  denominator FLOAT,
  is_alt_data STRING)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 4. lb_t_md_hierarchy_base_node_links_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_t_md_hierarchy_base_node_links_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  rn INT NOT NULL,
  hierarchy_name STRING,
  node_name STRING,
  node_desc STRING,
  node_level STRING,
  base_node_name STRING,
  base_node_desc STRING,
  is_leaf STRING,
  path STRING,
  multiplier DOUBLE,
  entity_has_mgmt_sales BOOLEAN,
  audit_created_tmstmp TIMESTAMP,
  audit_updated_tmstmp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 5. lb_t_md_report_configuration_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_t_md_report_configuration_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  page_id INT NOT NULL,
  report_id INT NOT NULL,
  report_name STRING,
  report_object STRING NOT NULL,
  column_id INT NOT NULL,
  measure_id INT,
  measure_name STRING,
  formula STRING,
  column_format_json STRING,
  is_default_desc_sorting BOOLEAN,
  table_id INT,
  report_row_node_name STRING,
  audit_created_tmstmp TIMESTAMP,
  audit_updated_tmstmp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 6. lb_t_sd_keyuser_by_brand_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_t_sd_keyuser_by_brand_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  userid STRING NOT NULL,
  brand STRING NOT NULL,
  audit_created_tmstmp TIMESTAMP,
  audit_updated_tmstmp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 7. lb_t_sd_keyuser_by_business_unit_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_t_sd_keyuser_by_business_unit_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  userid STRING NOT NULL,
  business_unit STRING NOT NULL,
  audit_created_tmstmp TIMESTAMP,
  audit_updated_tmstmp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 8. lb_t_sd_keyuser_by_entity_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_t_sd_keyuser_by_entity_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  userid STRING NOT NULL,
  entity STRING NOT NULL,
  audit_created_tmstmp TIMESTAMP,
  audit_updated_tmstmp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 9. lb_t_sd_keyuser_profile_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_t_sd_keyuser_profile_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  keyuser STRING NOT NULL,
  functional_area STRING,
  functional_area_list STRING,
  is_corp INT,
  is_global INT,
  is_business_unit INT,
  is_regional INT,
  has_ta_restriction INT,
  is_int INT,
  is_us INT,
  audit_created_tmstmp TIMESTAMP,
  audit_updated_tmstmp TIMESTAMP)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');

-- 10. lb_t_sd_user_profile_history
CREATE TABLE IF NOT EXISTS unifyplus_eu_finance.publish_fin_sync_poc.lb_t_sd_user_profile_history (
  _pg_change_type STRING NOT NULL,
  _pg_lsn BIGINT NOT NULL,
  _pg_xid INT NOT NULL,
  _timestamp TIMESTAMP_NTZ NOT NULL,
  _sort_by BIGINT NOT NULL,
  userid STRING NOT NULL,
  user_name STRING,
  alias STRING,
  domain STRING,
  role STRING,
  subrole_l1 STRING,
  subrole_l2 STRING,
  ta_restriction STRING,
  division_name STRING,
  identity_status STRING,
  worker_type STRING,
  applications STRING,
  ou STRING,
  ou_detail STRING,
  brand STRING,
  general_geo STRING,
  sensitive_geo STRING,
  loa STRING,
  write STRING,
  ad_domain STRING,
  country_name STRING,
  functional_title STRING,
  department_desc STRING,
  function_desc STRING,
  oplevel3_desc STRING,
  oplevel2_desc STRING,
  oplevel1_desc STRING,
  company_code STRING,
  oper_manager_id STRING,
  oper_manager_name STRING,
  userid_hash STRING)
USING delta
TBLPROPERTIES (
  'delta.feature.domainMetadata' = 'supported',
  'delta.feature.invariants' = 'supported',
  'delta.feature.timestampNtz' = 'supported',
  'delta.minReaderVersion' = '3',
  'delta.minWriterVersion' = '7');
