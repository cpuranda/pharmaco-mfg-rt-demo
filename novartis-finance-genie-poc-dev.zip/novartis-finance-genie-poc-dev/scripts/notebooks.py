"""Databricks notebook / UI artefacts for deploying the package through the workspace UI (no terminal)."""

from __future__ import annotations

import json

import run_sql  # statement splitter shared with the CLI runner

NB_SQL_HEAD = "-- Databricks notebook source\n"
NB_SEP = "\n\n-- COMMAND ----------\n\n"


def md_cell(md: str, lang: str = "sql") -> str:
    c = "--" if lang == "sql" else "#"
    lines = [f"{c} MAGIC %md"] + [f"{c} MAGIC {ln}".rstrip() for ln in md.strip().splitlines()]
    return "\n".join(lines)


def sql_notebook(title: str, intro: str, parts: list[tuple[str, str]], banner: str = "") -> str:
    cells = [md_cell(f"# {title}\n\n{banner}{intro}")]
    for heading, sql in parts:
        if heading:
            cells.append(md_cell(heading))
        cells += [s.strip() + ";" for s in run_sql.split_statements(sql)]
    return NB_SQL_HEAD + NB_SEP.join(cells) + "\n"


def rollback_sql(created: list[str]) -> str:
    lines = ["-- Drops ONLY the PoC objects this package created (never the lb_*_history tables)."]
    for obj in dict.fromkeys(reversed(created)):
        kind = "TABLE" if obj.endswith(".sec_poc_identity_map") else "VIEW"
        lines.append(f"DROP {kind} IF EXISTS {obj};")
    return "\n".join(lines) + "\n"


def genie_ui_markdown(cfg: dict, space: dict) -> str:
    ins = "".join(space["instructions"]["text_instructions"][0]["content"])
    qs = [q["question"][0] for q in space["config"]["sample_questions"]]
    ex = space["instructions"].get("example_question_sqls", [])
    table = space["data_sources"]["tables"][0]
    out = [
        f"# Genie space — UI setup ({cfg['env_label']})",
        "",
        "Create it in the workspace UI (**Genie → + New**), or run notebook `07_create_genie_space_OPTIONAL.py`, which does the same through the API.",
        "",
        f"1. **Title:** {cfg['genie_space_title']}",
        f"2. **SQL warehouse:** {cfg.get('warehouse_name') or cfg.get('warehouse_id')}",
        f"3. **Data:** add ONLY `{table['identifier']}` (no lb_*, src_cur_* or sec_* object).",
        f"   Description: {table['description'][0]}",
        "4. **Instructions → Text:** paste the block below exactly.",
        "5. **Instructions → SQL queries (example SQL):** add each question with its SQL below.",
        "6. **Settings → Sample questions:** add the questions below.",
        "7. **Share:** " + ", ".join(f"`{p}`" for p in cfg["persona_principals"]) + " → **Can run**.",
        "   Do not use embedded / shared credentials: each user must query with their OWN identity.",
        "",
        "## Text instructions",
        "",
        "```text",
        ins.rstrip(),
        "```",
        "",
        "## Sample questions",
        "",
        *[f"* {q}" for q in qs],
        "",
        "## Example SQL",
    ]
    for e in ex:
        out += ["", f"**Question:** {e['question'][0]}", "", "```sql", "".join(e["sql"]).rstrip(), "```"]
    return "\n".join(out) + "\n"


def genie_api_notebook(cfg: dict, fq_mv: str, space_json: str) -> str:
    desc = f"{cfg['env_label']} PoC. Single source: {fq_mv} (secured to the signed-in user)."
    head = [
        "# Databricks notebook source",
        "# MAGIC %md",
        "# MAGIC # 07 — Create the Genie space (OPTIONAL, API)",
        "# MAGIC Alternative to the manual UI steps in GENIE_SPACE_UI_SETUP.md. Run on serverless (or any cluster) as the deploying user.",
        "# MAGIC Creates the space with the Metric View as its ONLY source and gives the 4 test users CAN RUN.",
        "# MAGIC Run it ONCE (a second run creates a second space). If your workspace blocks these APIs, use the manual UI steps.",
        "",
        "# COMMAND ----------",
        "",
        "import json",
        "from databricks.sdk import WorkspaceClient",
        "",
        "w = WorkspaceClient()",
        f"WAREHOUSE_NAME = {json.dumps(cfg.get('warehouse_name') or '')}",
        f"WAREHOUSE_ID = {json.dumps(cfg.get('warehouse_id') or '')}",
        f"TITLE = {json.dumps(cfg['genie_space_title'])}",
        f"DESCRIPTION = {json.dumps(desc)}",
        f"USERS = {json.dumps(cfg['persona_principals'])}",
        f"SPACE = json.loads({json.dumps(space_json)})",
        "",
        "if not WAREHOUSE_ID:",
        "    hits = [x for x in w.warehouses.list() if x.name == WAREHOUSE_NAME]",
        '    assert len(hits) == 1, f"warehouse {WAREHOUSE_NAME!r} matched {len(hits)} warehouses"',
        "    WAREHOUSE_ID = hits[0].id",
        f'assert [t["identifier"] for t in SPACE["data_sources"]["tables"]] == [{json.dumps(fq_mv)}]',
        'print("warehouse", WAREHOUSE_ID)',
        "",
        "# COMMAND ----------",
        "",
        'resp = w.api_client.do("POST", "/api/2.0/genie/spaces", body={',
        '    "title": TITLE, "description": DESCRIPTION, "warehouse_id": WAREHOUSE_ID, "serialized_space": json.dumps(SPACE)})',
        'SPACE_ID = resp["space_id"]',
        'w.api_client.do("PATCH", f"/api/2.0/permissions/genie/{SPACE_ID}", body={',
        '    "access_control_list": [{"user_name": u, "permission_level": "CAN_RUN"} for u in USERS]})',
        "print(\"Genie space:\", f\"{w.config.host.rstrip('/')}/genie/rooms/{SPACE_ID}\")",
    ]
    return "\n".join(head) + "\n"
