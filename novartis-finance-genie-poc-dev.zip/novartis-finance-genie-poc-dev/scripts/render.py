#!/usr/bin/env python3
"""Render the Novartis DEV deployment package (Genie-only: no App, no service principals).

  python scripts/render.py novartis_dev --preflight          # phase 1 only: 00_preflight + 00c + 00d
  python scripts/render.py novartis_dev --pending-preflight  # everything; deploy notebooks carry a PENDING banner
  python scripts/render.py novartis_dev                      # final: refuses placeholders / unconfirmed preflight

Every render also writes Databricks notebooks for UI deployment (Workspace -> Import):
  build/<target>/notebooks/*.sql|*.py  +  build/<target>/GENIE_SPACE_UI_SETUP.md

Outputs (generated; do not edit by hand):
  build/<target>/rendered_sql/*.sql             SQL for scripts/run_sql.py
  build/<target>/warehouse_permissions.json     CAN_USE for the test users (PATCH, keeps existing ACLs)
  genie/build/<target>/genie_target.yml         bundle target for the Genie space
  genie/build/<target>/space.geniespace.json
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import notebooks as nbk  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
PLACEHOLDER = re.compile(r"<[A-Za-z0-9_.@\-]+>")
TEMPLATE_VAR = re.compile(r"\$\{([a-z_]+)\}")

PREFLIGHT_FILES = ["00_preflight.sql", "00d_preflight_semantics.sql"]
DEPLOY_FILES = [
    "01_security_views.sql",
    "02_metric_view.sql",
    "03_test_queries.sql",
    "03b_operator_oracle.sql",
    "04_identity_and_grants.sql",
]

# Logical Lakebase tables. Physical UC name = <prefix><name><suffix> (DEV: lb_<name>_history).
# In change-history mode every non-raw reference reads the generated view <fq>.src_cur_<name>.
SOURCE_TABLES = (
    "t_md_hierarchy_base_node_links",
    "config_t_md_page",
    "config_t_md_user_settings",
    "t_sd_keyuser_by_entity",
    "t_sd_keyuser_by_brand",
    "t_sd_keyuser_by_business_unit",
    "t_sd_keyuser_profile",
    "t_sd_user_profile",
    "t_md_report_configuration",
    "t_dtm_daily_sales_report_drill_down",
)
RAW_SOURCE_FILES = {"00_preflight.sql"}  # reads the physical history tables
SRC_REF = re.compile(r"\$\{src\}\.([A-Za-z_][A-Za-z0-9_]*)")
RAW_REF = re.compile(r"\$\{raw\}\.([A-Za-z_][A-Za-z0-9_]*)")


def sql_str(v: str) -> str:
    return "'" + str(v).replace("'", "''") + "'"


def sql_list(values: list[str], lower: bool = False) -> str:
    return ", ".join(sql_str(v.strip().lower() if lower else v) for v in values)


def die(msg: str) -> None:
    sys.exit(msg)


def load(target: str, preflight_only: bool, pending: bool = False) -> dict:
    cfg = json.loads((ROOT / "config" / f"{target}.json").read_text())
    for k in ("catalog", "schema", "source_catalog", "source_schema"):
        if not IDENT.match(cfg[k]):
            die(f"config {k}={cfg[k]!r} is not a safe identifier")
    same = f"{cfg['catalog']}.{cfg['schema']}".lower() == f"{cfg['source_catalog']}.{cfg['source_schema']}".lower()
    if same and not (cfg.get("source_table_prefix") or cfg.get("source_table_suffix")):
        die("source and target share a schema: a source_table_prefix/suffix is required to keep them apart")
    for k in ("source_table_prefix", "source_table_suffix"):
        if cfg.get(k) and not re.fullmatch(r"[A-Za-z0-9_]+", cfg[k]):
            die(f"config {k}={cfg[k]!r} is not a safe identifier fragment")
    if not isinstance(cfg.get("source_is_change_history"), bool):
        die("config source_is_change_history must be true or false")
    if cfg["source_is_change_history"]:
        h = cfg["change_history"]
        cols = [*h["order_columns"], h["operation_column"], *h["metadata_columns"]]
        cols += [c for ks in h["keys"].values() for c in ks]
        bad = [c for c in cols if not IDENT.match(c)]
        missing = [s for s in SOURCE_TABLES if not h["keys"].get(s)]
        if bad or missing or not h["order_columns"] or not h.get("live_values") or not h.get("delete_values"):
            die(f"change_history incomplete: bad columns={bad}, tables without keys={missing}")
        overlap = {v.lower() for v in h["live_values"]} & {v.lower() for v in [*h["delete_values"], *h.get("preimage_values", [])]}
        if overlap:
            die(f"change_history live_values overlap delete/preimage values: {sorted(overlap)}")
    wid, wname = cfg.get("warehouse_id"), cfg.get("warehouse_name")
    if wid is not None and not re.fullmatch(r"[0-9a-f]{16}", str(wid)):
        die(f"warehouse_id={wid!r} is not a 16-hex warehouse id (use warehouse_name for the display name)")
    if not wid and not wname:
        die("set warehouse_name (or warehouse_id)")
    if preflight_only:
        return cfg
    found = sorted(set(PLACEHOLDER.findall(json.dumps(cfg))))
    if found:
        die(f"config/{target}.json has unresolved placeholders: {', '.join(found)}")
    if cfg.get("preflight_confirmed") is not True and not pending:
        die("preflight_confirmed is not true: review 00_preflight + 00d results and confirm semantics first")
    users = [i["databricks_user"].lower() for i in cfg["identity_seed"]]
    if len(set(users)) != len(users):
        die("identity_seed maps the same Databricks user more than once (would resolve to AMBIGUOUS/UNMAPPED)")
    if sorted(users) != sorted(p.lower() for p in cfg["persona_principals"]):
        die("persona_principals must be exactly the users in identity_seed")
    asof = cfg["semantics"].get("as_of_date")
    if asof is not None and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(asof)):
        die("semantics.as_of_date must be null or YYYY-MM-DD")
    if asof is not None:
        try:
            dt.date.fromisoformat(asof)
        except ValueError:
            die("semantics.as_of_date is not a valid date")
    return cfg


def history_mode(cfg: dict) -> bool:
    return cfg.get("source_is_change_history") is True


def fq(cfg: dict) -> str:
    return f"{cfg['catalog']}.{cfg['schema']}"


def physical(cfg: dict, name: str) -> str:
    return (
        f"{cfg['source_catalog']}.{cfg['source_schema']}."
        f"{cfg.get('source_table_prefix', '')}{name}{cfg.get('source_table_suffix', '')}"
    )


def resolve_sources(text: str, cfg: dict, raw: bool) -> str:
    def check(name: str) -> None:
        if name not in SOURCE_TABLES:
            die(f"unknown source table referenced in SQL: {name}")

    def sub(m: re.Match) -> str:
        name = m.group(1)
        check(name)
        if history_mode(cfg) and not raw:
            return f"{fq(cfg)}.src_cur_{name}"
        return physical(cfg, name)

    def sub_raw(m: re.Match) -> str:
        check(m.group(1))
        return physical(cfg, m.group(1))

    return RAW_REF.sub(sub_raw, SRC_REF.sub(sub, text))


def op_expr(h: dict) -> str:
    return f"lower(trim({h['operation_column']}))"


def current_state_views(cfg: dict) -> str:
    """Latest change per key from a Lakebase change feed; a key is live only if its latest change is a live type.

    Pre-images take part in the ranking (a key whose newest image is a pre-image was moved away by a key
    update and must disappear); on a full tie the post-image wins. Unknown or NULL change types are
    treated as NOT live (fail closed).
    """
    h = cfg["change_history"]
    op = op_expr(h)
    hide = ", ".join(dict.fromkeys([*h["metadata_columns"], "_cs_rn"]))
    live = sql_list(h["live_values"], lower=True)
    pre = h.get("preimage_values", [])
    tie = f", CASE WHEN {op} IN ({sql_list(pre, lower=True)}) THEN 1 ELSE 0 END" if pre else ""
    order = ", ".join(f"{c} DESC" for c in h["order_columns"]) + tie
    out = [
        "-- GENERATED: current state of the Lakebase change-history tables (read-only on the source).",
        f"-- Change types: live={h['live_values']}, pre-image={pre}, delete={h['delete_values']}; anything else = not live.",
        "-- The security views read ONLY these views. Never granted to any user; they run with owner rights.",
        "",
    ]
    for name in SOURCE_TABLES:
        keys = ", ".join(h["keys"][name])
        out.append(f"""CREATE OR REPLACE VIEW {fq(cfg)}.src_cur_{name}
COMMENT 'Current state of {physical(cfg, name)} (latest change per key: {keys}; deleted / moved keys removed).'
AS
SELECT * EXCEPT ({hide})
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY {keys} ORDER BY {order}) AS _cs_rn
  FROM {physical(cfg, name)}
)
WHERE _cs_rn = 1
  AND {op} IN ({live});
""")
    return "\n".join(out)


def preflight_source_checks(cfg: dict) -> str:
    """Read-only checks on the physical history tables: change types, key validity, ties, grants."""
    h = cfg.get("change_history") or {}
    keys = h.get("keys", {})
    pre_, suf = cfg.get("source_table_prefix", ""), cfg.get("source_table_suffix", "")
    lines = [
        "",
        "-- ===== GENERATED source checks (read-only) =====",
        "-- P1: all 10 expected physical tables exist",
        f"SELECT table_name, table_type FROM {cfg['source_catalog']}.information_schema.tables",
        f"WHERE table_schema = {sql_str(cfg['source_schema'])} AND table_name IN ("
        + ", ".join(sql_str(f"{pre_}{n}{suf}") for n in SOURCE_TABLES)
        + ")",
        "ORDER BY table_name;   -- expect 10 rows",
        "",
    ]
    if not history_mode(cfg):
        return "\n".join(lines) + "\n"
    op = op_expr(h)
    known = sql_list([*h["live_values"], *h.get("preimage_values", []), *h["delete_values"]], lower=True)
    dels = sql_list(h["delete_values"], lower=True)
    ins = sql_str(h["live_values"][0].lower())
    order = h["order_columns"]
    lines += [
        "-- P2: change-type distribution per table. Every value must be one of: " + known,
        "--     (any other value is treated as NOT live -> rows disappear; tell the Databricks team)",
    ]
    lines.append(
        "\nUNION ALL\n".join(
            f"SELECT {sql_str(n)} AS logical_table, {op} AS change_type, COUNT(*) AS change_rows, "
            f"MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM {physical(cfg, n)} GROUP BY {op}"
            for n in SOURCE_TABLES
        )
        + "\nORDER BY logical_table, change_type;"
    )
    lines += [
        "",
        "-- P3: key validation per table. ALL of these columns must be 0, otherwise the key in",
        "--     config change_history.keys is wrong for that table (do NOT deploy; adjust and re-render):",
        "--     keys_with_multiple_live_inserts: a key inserted twice without a delete in between -> key too narrow",
        "--     key_null_in_delete_or_preimage: delete/pre-image rows with a NULL key column -> key too wide",
        "--     unknown_change_type_rows: change types outside the configured lists",
        "--     full_order_ties: two changes of one key with the same ordering columns (ambiguous latest)",
    ]
    parts = []
    for n in SOURCE_TABLES:
        k = keys[n]
        kl = ", ".join(k)
        null_any = " OR ".join(f"{c} IS NULL" for c in k)
        parts.append(
            f"""SELECT {sql_str(n)} AS logical_table,
  (SELECT COUNT(*) FROM (SELECT {kl} FROM {physical(cfg, n)} GROUP BY {kl}
     HAVING SUM(CASE WHEN {op} = {ins} THEN 1 ELSE 0 END) - SUM(CASE WHEN {op} IN ({dels}) THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM {physical(cfg, n)} WHERE {op} IN ({sql_list([*h["delete_values"], *h.get("preimage_values", [])], lower=True)}) AND ({null_any}))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM {physical(cfg, n)} WHERE {op} IS NULL OR {op} NOT IN ({known})) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT {kl}, {", ".join(order)} FROM {physical(cfg, n)}
     WHERE {op} NOT IN ({sql_list(h.get("preimage_values", []) or ["__none__"], lower=True)})
     GROUP BY {kl}, {", ".join(order)} HAVING COUNT(*) > 1)) AS full_order_ties"""
        )
    lines.append("\nUNION ALL\n".join(parts) + "\nORDER BY logical_table;")
    lines += [
        "",
        "-- P4: history volume vs current state (informational: rows > keys means several versions per key)",
    ]
    lines.append(
        "\nUNION ALL\n".join(
            f"SELECT {sql_str(n)} AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT {', '.join(keys[n])}) AS distinct_keys "
            f"FROM {physical(cfg, n)}"
            for n in SOURCE_TABLES
        )
        + "\nORDER BY logical_table;"
    )
    lines += [
        "",
        "-- P5: existing grants of the test users on the SOURCE schema. If a test user can SELECT the raw",
        "--     lb_*_history tables directly, a free-form Genie / SQL session could bypass the governed path.",
        "--     The Genie space itself only uses the Metric View; record these findings for the security review.",
    ]
    for u in cfg["persona_principals"]:
        lines.append(f"SHOW GRANTS `{u}` ON SCHEMA {cfg['source_catalog']}.{cfg['source_schema']};")
    lines.append(f"SHOW GRANTS ON SCHEMA {fq(cfg)};   -- target schema: deploying user needs CREATE TABLE + CREATE VIEW (+ MANAGE to grant)")
    return "\n".join(lines) + "\n"


def name_search(cfg: dict) -> str:
    """R11: find the test users in the Finance user profile by their login ID and name tokens (read-only)."""
    tokens: list[str] = []
    for i in cfg["identity_seed"]:
        local = i["databricks_user"].split("@")[0].lower().replace("_ext", "")
        tokens += [t for t in re.split(r"[._\-]", local) if len(t) >= 4]
        tokens += [t.strip().lower() for t in i.get("name_tokens", []) if len(t.strip()) >= 4]
    if not tokens:
        return ""
    cond = "\n   OR ".join(
        f"lower(coalesce(user_name, '')) LIKE {sql_str('%' + t + '%')} OR lower(coalesce(alias, '')) LIKE {sql_str('%' + t + '%')}"
        for t in dict.fromkeys(tokens)
    )
    return cond


def period_labels(cfg: dict) -> tuple[str, str, str]:
    """Wording for the reporting period: live current month, or the month fixed by semantics.as_of_date."""
    s = cfg["semantics"]
    asof = s.get("as_of_date")
    if not asof:
        return "current-month", f"{s['business_timezone']} business date", "Current-month-to-date"
    month = dt.date.fromisoformat(asof).strftime("%B %Y")
    return month, f"fixed demo period, as_of_date {asof}", f"{month} month-to-date"


def variables(cfg: dict) -> dict[str, str]:
    s = cfg["semantics"]
    seed = ",\n".join(
        f"  ({sql_str(i['databricks_user'].lower())}, {sql_str(i['finance_userid'])}, 'ACTIVE', true, 'POC_SEED', "
        "current_timestamp(), NULL, current_timestamp())"
        for i in cfg["identity_seed"]
    )
    asof = s.get("as_of_date")
    bdate = f"DATE'{asof}'" if asof else f"to_date(from_utc_timestamp(current_timestamp(), {sql_str(s['business_timezone'])}))"
    pname, pnote, pmtd = period_labels(cfg)
    return {
        "period_name": pname,
        "period_note": pnote,
        "period_mtd": pmtd,
        "catalog": cfg["catalog"],
        "schema": cfg["schema"],
        "fq": fq(cfg),
        "src": f"{cfg['source_catalog']}.{cfg['source_schema']}",  # bare ${src} = physical source schema
        "page_id": str(int(s["page_id"])),
        "measure_name": s["measure_name"],
        "account_code": s["account_code"],
        "business_tz": s["business_timezone"],
        "business_date_sql": bdate,
        "entity_hier": s["entity_hierarchy"],
        "brand_hier_list": sql_list(s["brand_hierarchies"]),
        "bu_hier": s["business_unit_hierarchy"],
        "market_list": sql_list([m.upper() for m in s["markets"]]),
        "app_code": s["application_code"],
        "active_status": s["active_status"],
        "alt_data_values": sql_list(s["alt_data_actual_values"], lower=True),
        "leaf_values": sql_list(s["leaf_true_values"], lower=True),
        "identity_seed_values": seed,
        "name_search": name_search(cfg) or "false",
        "seed_userid_rows": ",\n  ".join(
            f"({sql_str(i['databricks_user'].lower())}, {sql_str(i['finance_userid'])})" for i in cfg["identity_seed"]
        ),
    }


MULTILINE_VARS = ("identity_seed_values", "name_search", "seed_userid_rows")


def render_sql(text: str, v: dict[str, str], cfg: dict) -> str:
    for line in text.splitlines():
        if line.lstrip().startswith("--") and any("${" + m + "}" in line for m in MULTILINE_VARS):
            die(f"multi-line placeholder used inside a SQL comment: {line.strip()}")
    text = re.sub(
        r"-- @persona-grants-begin\n(.*?)-- @persona-grants-end",
        lambda m: "\n".join(m.group(1).replace("${principal}", p) for p in cfg["persona_principals"]),
        text,
        flags=re.S,
    )
    def usage(m: re.Match) -> str:
        dep = (cfg.get("deploying_user") or "").lower()
        users = [p for p in cfg["persona_principals"] if p.lower() != dep]
        stmts = [ln.replace("${principal}", p) for p in users for ln in m.group(1).strip().splitlines()]
        stmts = [TEMPLATE_VAR.sub(lambda x: v[x.group(1)], s) for s in stmts]
        if cfg.get("usage_grants_by") == "platform_team":
            cfg.setdefault("_platform_grants", [])
            cfg["_platform_grants"] = list(dict.fromkeys([*cfg["_platform_grants"], *stmts]))
            return "-- NOT EXECUTED: granted by the Novartis platform team (see PLATFORM_TEAM_GRANTS.sql)\n" + "".join(
                f"-- {s}\n" for s in stmts
            )
        return "\n".join(stmts) + "\n"

    text = re.sub(r"-- @usage-grants-begin\n(.*?)-- @usage-grants-end\n", usage, text, flags=re.S)
    if not cfg.get("create_schema"):
        text = re.sub(r"-- @create-schema-begin\n.*?-- @create-schema-end\n", "", text, flags=re.S)
    left = sorted({m for m in TEMPLATE_VAR.findall(text) if m not in v})
    if left:
        die(f"unknown template variables: {left}")
    return TEMPLATE_VAR.sub(lambda m: v[m.group(1)], text)


def render_file(name: str, v: dict[str, str], cfg: dict) -> str:
    text = resolve_sources((ROOT / "sql" / name).read_text(), cfg, raw=name in RAW_SOURCE_FILES)
    text = render_sql(text, v, cfg)
    if name == "00_preflight.sql":
        text += preflight_source_checks(cfg)
    return text


def principal_entry(level: str, p: str) -> str:
    key = "user_name" if "@" in p else "service_principal_name"
    return f'            - {{level: {level}, {key}: "{p}"}}'


def pin_genie_period(space_json: str, cfg: dict) -> str:
    """Fixed demo period: tell Genie the period is pinned so it never adds its own current_date() filter."""
    month, _, _ = period_labels(cfg)
    asof = cfg["semantics"]["as_of_date"]
    old_rule = "4. The latest available current-month reporting date is already enforced; report it as reporting_date.\n"
    new_rule = (
        f"4. The reporting period is fixed to {month} month-to-date (the latest available reporting date up to {asof}) "
        "and is already enforced in the source. \"This month\", \"current month\" and \"MTD\" mean that period. "
        "Never add date filters (no current_date(), now(), date_trunc() or reporting_date conditions); "
        "report reporting_date as returned.\n"
    )
    old_desc = "Authorized current-month Daily Sales"
    space = json.loads(space_json)
    lines = space["instructions"]["text_instructions"][0]["content"]
    if lines.count(old_rule) != 1:
        die("Genie template: period rule not found exactly once")
    lines[lines.index(old_rule)] = new_rule
    for t in space["data_sources"]["tables"]:
        t["description"] = [d.replace(old_desc, f"Authorized {month} (fixed demo period) Daily Sales") for d in t["description"]]
    return json.dumps(space, indent=2, ensure_ascii=False) + "\n"


def genie_files(cfg: dict) -> tuple[str, str]:
    template = (ROOT / "genie" / "finance_genie_poc.geniespace.json").read_text()
    s = cfg["semantics"]
    fq_mv = f"{fq(cfg)}.mv_brand_performance_actuals_mtd"
    out = re.sub(r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+\.mv_brand_performance_actuals_mtd", fq_mv, template)
    out = out.replace("IS01_100", s["account_code"]).replace("DS_MTD_MtdActCY", s["measure_name"])
    if s.get("as_of_date"):
        out = pin_genie_period(out, cfg)
    perms = "\n".join(principal_entry("CAN_RUN", p) for p in cfg["persona_principals"])
    yml = f"""# GENERATED by scripts/render.py from config/{cfg["target"]}.json — do not edit.
targets:
  {cfg["target"]}:
    workspace:
      host: {cfg["host"]}
      profile: {cfg["profile"]}
    variables:
{warehouse_var(cfg)}
    resources:
      genie_spaces:
        finance_genie_poc:
          title: "{cfg["genie_space_title"]}"
          description: >-
            {cfg["env_label"]} PoC. Single source: {fq_mv} (secured to the signed-in user's Finance entitlements).
          warehouse_id: ${{var.warehouse_id}}
          file_path: ./space.geniespace.json
          permissions:
{perms}
"""
    return out, yml


def warehouse_var(cfg: dict) -> str:
    if cfg.get("warehouse_id"):
        return f'      warehouse_id: "{cfg["warehouse_id"]}"'
    return f'      warehouse_id:\n        lookup:\n          warehouse: "{cfg["warehouse_name"]}"'


def warehouse_permissions(cfg: dict) -> str:
    acl = [{"user_name": p, "permission_level": "CAN_USE"} for p in cfg["persona_principals"]]
    return json.dumps({"access_control_list": acl}, indent=2) + "\n"


WRITE_STMT = re.compile(
    r"\b(?:CREATE(?:\s+OR\s+REPLACE)?\s+(?:VIEW|TABLE)(?:\s+IF\s+NOT\s+EXISTS)?|INSERT\s+(?:INTO|OVERWRITE)(?:\s+TABLE)?"
    r"|DELETE\s+FROM|UPDATE|MERGE\s+INTO|DROP\s+(?:VIEW|TABLE)(?:\s+IF\s+EXISTS)?|ALTER\s+(?:VIEW|TABLE)|TRUNCATE\s+TABLE)\s+([A-Za-z0-9_.`]+)",
    re.I,
)


def written_objects(sql: str) -> list[str]:
    code = re.sub(r"--[^\n]*", "", sql)
    return [m.group(1).strip("`").lower() for m in WRITE_STMT.finditer(code)]


def guard_writes(name: str, sql: str, cfg: dict) -> None:
    """Never write a source table; only write PoC-prefixed objects in the target schema."""
    sources = {physical(cfg, n).lower() for n in SOURCE_TABLES}
    for obj in written_objects(sql):
        if obj in sources:
            die(f"{name}: refusing to write source table {obj}")
        leaf = obj.rsplit(".", 1)[-1]
        if not obj.startswith(fq(cfg).lower() + ".") or not re.match(r"(src_cur_|sec_|mv_)", leaf):
            die(f"{name}: write outside the PoC object set: {obj}")


def platform_sql(cfg: dict) -> str:
    users = [p for p in cfg["persona_principals"] if p.lower() != (cfg.get("deploying_user") or "").lower()]
    head = [
        f"-- Request to the Novartis platform team — {cfg['env_label']} Finance Genie PoC",
        f"-- Please grant catalog / schema usage to these {len(users)} test users: " + ", ".join(users) + ".",
        "-- Usage only: no SELECT, MODIFY or other data privilege (table-level SELECT on two PoC views is granted by the PoC owner).",
        f"-- Optional, if not yet granted: CAN USE on SQL warehouse {cfg.get('warehouse_name') or cfg.get('warehouse_id')} for the same users.",
        "",
    ]
    return "\n".join(head + cfg["_platform_grants"]) + "\n"


def platform_md(cfg: dict) -> str:
    body = "\n".join(cfg["_platform_grants"])
    return (
        "## Catalog / schema usage — granted by the Novartis platform team (NOT run here)\n\n"
        "These statements are intentionally not executed in this notebook. Send `PLATFORM_TEAM_GRANTS.sql` to the platform team; "
        "the users can query only after these grants exist (check with the SHOW GRANTS ON SCHEMA cell above).\n\n"
        "```sql\n" + body + "\n```"
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("target")
    ap.add_argument("--preflight", action="store_true", help="render only the read-only preflight + current-state views")
    ap.add_argument("--pending-preflight", action="store_true", help="render everything; deploy notebooks carry a PENDING banner")
    a = ap.parse_args()
    cfg = load(a.target, a.preflight, a.pending_preflight)
    v = variables(cfg)
    pending = cfg.get("preflight_confirmed") is not True

    base = ROOT / "build" / a.target
    out, nbdir = base / "rendered_sql", base / "notebooks"
    for d in (out, nbdir):
        d.mkdir(parents=True, exist_ok=True)
        for old in d.glob("*.*"):
            old.unlink()
    rendered = {f: render_file(f, v, cfg) for f in PREFLIGHT_FILES + ([] if a.preflight else DEPLOY_FILES)}
    if history_mode(cfg):
        cs = current_state_views(cfg)
        if PLACEHOLDER.search(cs):
            die("current-state views would contain placeholders")
        rendered["00c_current_state_views.sql"] = cs
    created: list[str] = []
    for f in sorted(rendered):
        guard_writes(f, rendered[f], cfg)
        if f != "04_identity_and_grants.sql":
            created += [o for o in written_objects(rendered[f])]
        (out / f).write_text(rendered[f])

    banner = (
        "> **PENDING PREFLIGHT CONFIRMATION.** Run notebooks 01-03 first and continue only if every gate passed; "
        "otherwise send the results back for a re-rendered package.\n\n"
        if pending
        else ""
    )
    wh = cfg.get("warehouse_name") or cfg.get("warehouse_id")
    src = f"{cfg['source_catalog']}.{cfg['source_schema']}"
    nb = {
        "01_preflight_raw_READ_ONLY.sql": (
            "01 - Preflight on the raw history tables (READ-ONLY)",
            f"Attach to SQL warehouse **{wh}** and **Run all**. Nothing is written; reads `{src}.lb_*_history`.\n\n"
            "**Gates:** P0 = your login exactly as in the mapping; P1 = 10 tables; P2 only insert / update_preimage / "
            "update_postimage / delete; **P3 all zeros**; P5 record the grants.",
            [("", rendered["00_preflight.sql"])],
        ),
        "02_create_current_state_views.sql": (
            "02 - Create the current-state views",
            "Creates 10 views `src_cur_*` (latest change per key; deletes removed). Views only; the lb_* tables are never modified.",
            [("", rendered.get("00c_current_state_views.sql", ""))],
        ),
        "03_preflight_semantics_READ_ONLY.sql": (
            "03 - Preflight on current state (READ-ONLY)",
            "Confirm R2 account, R3 exactly one measure id, R4 hierarchies and markets, R5 status / application, R8 flag values, "
            f"R10 data present for {period_labels(cfg)[0]}, and **R12 the 4 mapped users** (in profile, Active, GENIE2, own keyuser, expected scope counts).",
            [("", rendered["00d_preflight_semantics.sql"])],
        ),
    }
    if not a.preflight:
        nb.update(
            {
                "04_deploy_governed_objects.sql": (
                    "04 - Deploy the governed objects",
                    "Creates the identity bridge, the security views and the Metric View, seeds the 4 user mappings and the grants. "
                    "Re-run this whole notebook after any re-run of notebook 02 (CREATE OR REPLACE VIEW drops grants).",
                    [
                        ("## Security views", rendered["01_security_views.sql"]),
                        ("## Metric View (the only Genie source)", rendered["02_metric_view.sql"]),
                        ("## Identity seed and object grants", rendered["04_identity_and_grants.sql"]),
                        *([(platform_md(cfg), "")] if cfg.get("_platform_grants") else []),
                    ],
                ),
                "05_expected_results_DEPLOYER.sql": (
                    "05 - Expected results per user (deploying user only)",
                    "Independent oracle (does not use current_user()). Keep the Europe totals to compare with notebook 06 and with Genie.",
                    [("", rendered["03b_operator_oracle.sql"])],
                ),
                "06_per_user_validation.sql": (
                    "06 - Per-user validation (EACH test user, signed in as themselves)",
                    "Share this notebook with the 4 users (Can run). [identity] must be AUTHORIZED with their userid; "
                    "[totals] EUROPE = their row in notebook 05; the [denial] cells must FAIL (except for the deploying user, "
                    "who owns the objects). Run cell by cell so the expected failures do not stop the run.",
                    [("", rendered["03_test_queries.sql"])],
                ),
                "99_rollback.sql": (
                    "99 - Rollback (drops only PoC objects)",
                    "Delete the Genie space in the UI first. The lb_*_history tables are never touched.",
                    [("", nbk.rollback_sql(created))],
                ),
            }
        )
    for name, (title, intro, parts) in nb.items():
        (nbdir / name).write_text(nbk.sql_notebook(title, intro, parts, banner if name[:2] in ("04", "05", "06") else ""))
    if a.preflight:
        print(f"rendered {a.target} PREFLIGHT ONLY: {out.relative_to(ROOT)}, {nbdir.relative_to(ROOT)}")
        return

    (base / "warehouse_permissions.json").write_text(warehouse_permissions(cfg))
    if cfg.get("_platform_grants"):
        (base / "PLATFORM_TEAM_GRANTS.sql").write_text(platform_sql(cfg))
    gout = ROOT / "genie" / "build" / a.target
    gout.mkdir(parents=True, exist_ok=True)
    space, yml = genie_files(cfg)
    (gout / "space.geniespace.json").write_text(space)
    (gout / "genie_target.yml").write_text(yml)
    (base / "GENIE_SPACE_UI_SETUP.md").write_text(nbk.genie_ui_markdown(cfg, json.loads(space)))
    fq_mv = f"{fq(cfg)}.mv_brand_performance_actuals_mtd"
    (nbdir / "07_create_genie_space_OPTIONAL.py").write_text(nbk.genie_api_notebook(cfg, fq_mv, json.dumps(json.loads(space))))
    state = " (PENDING PREFLIGHT CONFIRMATION)" if pending else ""
    print(f"rendered {a.target}{state}: {base.relative_to(ROOT)}, {gout.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
