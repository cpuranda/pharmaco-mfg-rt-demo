#!/usr/bin/env python3
"""Execute RENDERED PoC SQL (build/<target>/rendered_sql/*.sql) against the target warehouse.

  python scripts/render.py fevm
  python scripts/run_sql.py --target fevm render build/fevm/rendered_sql/01_security_views.sql   # print only
  python scripts/run_sql.py --target fevm run    build/fevm/rendered_sql/01_security_views.sql   # execute as CLI profile

* Host, profile and warehouse come from config/<target>.json.
* Refuses to run if the CLI profile does not point at the configured host.
* Refuses to run if any ${placeholder} is unresolved (only ${app_sp} is filled here, via --var).
* Refuses to run files rendered for a different target.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HOST = PROFILE = WAREHOUSE = ""
PLACEHOLDER = re.compile(r"\$\{([a-z0-9_]+)\}")


def render(text: str, variables: dict[str, str], principals: list[str]) -> str:
    def block(m: re.Match) -> str:
        body = m.group(1)
        return "\n".join(body.replace("${principal}", p) for p in principals)

    text = re.sub(r"-- @persona-grants-begin\n(.*?)-- @persona-grants-end", block, text, flags=re.S)
    text = PLACEHOLDER.sub(lambda m: variables.get(m.group(1), m.group(0)), text)
    missing = sorted(set(PLACEHOLDER.findall(text)))
    if missing:
        sys.exit(f"unresolved placeholders: {', '.join(missing)}")
    return text


def split_statements(text: str) -> list[str]:
    out, buf, in_dollar = [], [], False
    for line in text.splitlines():
        if line.strip().startswith("--") and not in_dollar and not buf:
            continue
        buf.append(line)
        in_dollar ^= line.count("$$") % 2 == 1
        if not in_dollar and line.rstrip().endswith(";"):
            stmt = "\n".join(buf).strip().rstrip(";").strip()
            if stmt and not all(ln.strip().startswith("--") or not ln.strip() for ln in stmt.splitlines()):
                out.append(stmt)
            buf = []
    tail = "\n".join(buf).strip()
    if tail and not all(ln.strip().startswith("--") or not ln.strip() for ln in tail.splitlines()):
        out.append(tail)
    return out


def check_profile() -> None:
    cfg = (Path.home() / ".databrickscfg").read_text()
    m = re.search(rf"\[{re.escape(PROFILE)}\][^\[]*?host\s*=\s*(\S+)", cfg, re.S)
    if not m or m.group(1).rstrip("/") != HOST.rstrip("/"):
        sys.exit(f"profile {PROFILE} does not point at {HOST}; refusing to run")


def resolve_warehouse(name: str) -> str:
    """Warehouse display name -> id (exactly one match required)."""
    p = subprocess.run(["databricks", "warehouses", "list", "--profile", PROFILE, "-o", "json"], capture_output=True, text=True)
    if p.returncode:
        sys.exit(f"cannot list warehouses: {p.stderr[-300:]}")
    hits = [w for w in json.loads(p.stdout or "[]") if w.get("name") == name]
    if len(hits) != 1:
        sys.exit(f"warehouse name {name!r} matched {len(hits)} warehouses; set warehouse_id in the config instead")
    print(f"warehouse {name} -> {hits[0]['id']} ({hits[0].get('warehouse_type', '?')}, {hits[0].get('state', '?')})")
    return hits[0]["id"]


def execute(stmt: str) -> dict:
    body = json.dumps(
        {
            "warehouse_id": WAREHOUSE,
            "statement": stmt,
            "wait_timeout": "50s",
            "on_wait_timeout": "CONTINUE",
            "disposition": "INLINE",
            "format": "JSON_ARRAY",
        }
    )
    p = subprocess.run(
        ["databricks", "api", "post", "/api/2.0/sql/statements", "--profile", PROFILE, "--json", body],
        capture_output=True,
        text=True,
    )
    if p.returncode:
        return {"status": {"state": "CLI_ERROR", "error": {"message": p.stderr[-500:]}}}
    resp = json.loads(p.stdout)
    sid = resp.get("statement_id")
    while (resp.get("status") or {}).get("state") in ("PENDING", "RUNNING"):
        p = subprocess.run(
            ["databricks", "api", "get", f"/api/2.0/sql/statements/{sid}", "--profile", PROFILE], capture_output=True, text=True
        )
        resp = json.loads(p.stdout)
    return resp


def main() -> None:
    global HOST, PROFILE, WAREHOUSE
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", required=True, help="config/<target>.json")
    ap.add_argument("action", choices=("render", "run"))
    ap.add_argument("files", nargs="+")
    ap.add_argument("--var", action="append", default=[], help="name=value")
    ap.add_argument("--principal", action="append", default=[])
    ap.add_argument("--continue-on-error", action="store_true")
    a = ap.parse_args()
    variables = dict(v.split("=", 1) for v in a.var)
    cfg = json.loads((ROOT / "config" / f"{a.target}.json").read_text())
    HOST, PROFILE = cfg["host"], cfg["profile"]
    WAREHOUSE = cfg.get("warehouse_id") or ""
    if a.action == "run" and re.search(r"<[A-Za-z0-9_.@\-]+>", HOST + PROFILE + WAREHOUSE + (cfg.get("warehouse_name") or "")):
        sys.exit(f"config/{a.target}.json still has placeholders; refusing to run")
    for f in a.files:
        if Path(f).resolve().parts[-3:-2] != (a.target,):
            sys.exit(f"{f} was not rendered for target {a.target}; refusing to run")

    for f in a.files:
        stmts = split_statements(render(Path(f).read_text(), variables, a.principal))
        if a.action == "render":
            print(f"-- ===== {f}: {len(stmts)} statements")
            for s in stmts:
                print(s + ";\n")
            continue
        check_profile()
        if not WAREHOUSE:
            WAREHOUSE = resolve_warehouse(cfg["warehouse_name"])
        for i, s in enumerate(stmts, 1):
            r = execute(s)
            state = (r.get("status") or {}).get("state")
            head = " ".join(s.split())[:110]
            print(f"[{f} {i}/{len(stmts)}] {state}: {head}")
            if state != "SUCCEEDED":
                print("   ", ((r.get("status") or {}).get("error") or {}).get("message", "")[:600])
                if not a.continue_on_error:
                    sys.exit(1)
            elif r.get("result", {}).get("data_array") and r["manifest"]["schema"]["columns"]:
                cols = [c["name"] for c in r["manifest"]["schema"]["columns"]]
                print("    " + " | ".join(cols))
                for row in r["result"]["data_array"][:40]:
                    print("    " + " | ".join("NULL" if v is None else str(v) for v in row))


if __name__ == "__main__":
    main()
