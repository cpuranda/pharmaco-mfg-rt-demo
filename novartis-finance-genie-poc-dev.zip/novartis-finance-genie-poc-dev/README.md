# Novartis Finance Genie PoC — Novartis DEV package (workspace UI, Genie-only)

Deploys the governed Finance Genie brand-performance PoC into the Novartis DEV workspace using only the
workspace UI. Source = the 10 copied Lakebase change-history tables `lb_*_history` in
`f1common_eu_platform.chandra_fin_genie_poc` (read only); all PoC objects (`src_cur_*`, `sec_*`, `mv_*`) are
created in the same schema. Consumed through a Genie space by four test users with their own Entra ID.
No Databricks App, no service principals.

**Start here:** [docs/DEV_DEPLOYMENT_GUIDE.md](docs/DEV_DEPLOYMENT_GUIDE.md) and import the notebooks in
`build/novartis_dev/notebooks/` (Workspace → Import). Genie space values: `build/novartis_dev/GENIE_SPACE_UI_SETUP.md`.

Re-render (FE workstation only): `python3 scripts/render.py novartis_dev --pending-preflight` · tests: `uv run pytest` (30).
