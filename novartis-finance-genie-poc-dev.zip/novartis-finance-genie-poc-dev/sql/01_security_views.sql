-- Governed security path for the Finance Genie PoC — Novartis DEV (Genie-only, no App).
-- Placeholders (scripts/render.py): fq = target catalog.schema (the ONLY schema written);
-- every source reference resolves to the current-state view src_cur_{table} in the target schema,
-- built over the read-only Lakebase history tables; semantics from config/novartis_dev.json.
-- Each test user asks Genie with their own identity; current_user() is that user's login (521 ID, e.g. PURANCH1@novartis.net).
--
-- Security model:
--   * Identity comes ONLY from current_user() evaluated in the querying user's Genie / SQL session.
--   * sec_poc_identity_map bridges Databricks identity -> Finance userid. Ambiguous or
--     missing mappings resolve to zero rows (fail closed).
--   * Finance userid -> keyuser via config_t_md_user_settings (multiple keyusers =
--     additive union, evaluated PER KEYUSER: a row is visible only if one keyuser
--     allows its entity AND brand AND business unit together).
--   * Raw history tables, src_cur_* views and sec_poc_identity_map are never granted to end users or Genie;
--     views run with the view owner's rights on the underlying tables.

-- Identity bridge --------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ${fq}.sec_poc_identity_map (
  databricks_user STRING NOT NULL COMMENT 'current_user() value (login 521 ID), stored lower-case',
  finance_userid STRING NOT NULL,
  identity_status STRING NOT NULL COMMENT 'ACTIVE | DISABLED',
  is_demo_user BOOLEAN NOT NULL,
  source STRING NOT NULL,
  valid_from TIMESTAMP,
  valid_to TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
) COMMENT 'PoC identity bridge. Approved DEV test users only. Never granted to end users.';

-- Internal: currently valid mappings
CREATE OR REPLACE VIEW ${fq}.sec_v_identity_map_active
COMMENT 'Internal. Currently valid identity mappings.'
AS
SELECT lower(databricks_user) AS databricks_user, finance_userid
FROM ${fq}.sec_poc_identity_map
WHERE identity_status = 'ACTIVE'
  AND (valid_from IS NULL OR valid_from <= current_timestamp())
  AND (valid_to IS NULL OR valid_to > current_timestamp());

-- Internal (all users): identity -> Finance user -> keyuser
CREATE OR REPLACE VIEW ${fq}.sec_v_user_keyuser
COMMENT 'Internal. Not granted to end users. Active Finance users with ${app_code} access and a registered keyuser.'
AS
SELECT DISTINCT
  i.databricks_user,
  i.finance_userid,
  s.keyuser,
  p.identity_status,
  p.role,
  p.country_name,
  p.general_geo
FROM ${fq}.sec_v_identity_map_active i
JOIN ${src}.config_t_md_user_settings s
  ON s.userid = i.finance_userid
JOIN ${src}.t_sd_user_profile p
  ON p.userid = s.userid
JOIN ${src}.t_sd_keyuser_profile kp
  ON kp.keyuser = s.keyuser
WHERE p.identity_status = '${active_status}'
  AND array_contains(transform(split(coalesce(p.applications, ''), '[;,]'), x -> upper(trim(x))), '${app_code}')
  AND s.keyuser IS NOT NULL
  AND trim(s.keyuser) <> '';

-- Internal (caller only): keyusers of the CURRENT user, only if the identity maps to
-- exactly one Finance userid.
CREATE OR REPLACE VIEW ${fq}.sec_v_caller_keyuser
COMMENT 'Internal. Keyusers of current_user(); empty unless exactly one Finance userid is mapped.'
AS
WITH mapped AS (
  SELECT COUNT(DISTINCT finance_userid) AS n
  FROM ${fq}.sec_v_identity_map_active
  WHERE databricks_user = lower(current_user())
)
SELECT k.finance_userid, k.keyuser
FROM ${fq}.sec_v_user_keyuser k
CROSS JOIN mapped m
WHERE k.databricks_user = lower(current_user())
  AND m.n = 1;

-- Caller-scoped allowlists ------------------------------------------------------
CREATE OR REPLACE VIEW ${fq}.sec_v_keyuser_entity
COMMENT 'Entity allowlist of the current user (per keyuser).'
AS
SELECT DISTINCT c.finance_userid, c.keyuser, e.entity
FROM ${fq}.sec_v_caller_keyuser c
JOIN ${src}.t_sd_keyuser_by_entity e
  ON e.userid = c.keyuser;

CREATE OR REPLACE VIEW ${fq}.sec_v_keyuser_brand
COMMENT 'Brand allowlist of the current user (per keyuser).'
AS
SELECT DISTINCT c.finance_userid, c.keyuser, b.brand
FROM ${fq}.sec_v_caller_keyuser c
JOIN ${src}.t_sd_keyuser_by_brand b
  ON b.userid = c.keyuser;

CREATE OR REPLACE VIEW ${fq}.sec_v_keyuser_business_unit
COMMENT 'Business-unit allowlist of the current user (per keyuser).'
AS
SELECT DISTINCT c.finance_userid, c.keyuser, u.business_unit
FROM ${fq}.sec_v_caller_keyuser c
JOIN ${src}.t_sd_keyuser_by_business_unit u
  ON u.userid = c.keyuser;

-- Identity self-check for each test user ("who am I in Finance?"), evaluated as current_user() ------
CREATE OR REPLACE VIEW ${fq}.sec_v_current_user_finance_identity
COMMENT 'Exactly one row: Finance identity of current_user(). resolution_status must be AUTHORIZED to proceed.'
AS
WITH mapped AS (
  SELECT COUNT(DISTINCT finance_userid) AS n, MIN(finance_userid) AS finance_userid
  FROM ${fq}.sec_v_identity_map_active
  WHERE databricks_user = lower(current_user())
),
ku AS (
  SELECT COUNT(DISTINCT keyuser) AS n, array_join(array_sort(collect_set(keyuser)), ',') AS keyusers
  FROM ${fq}.sec_v_caller_keyuser
),
ent AS (SELECT COUNT(DISTINCT entity) AS n FROM ${fq}.sec_v_keyuser_entity),
brd AS (SELECT COUNT(DISTINCT brand) AS n FROM ${fq}.sec_v_keyuser_brand),
bus AS (SELECT COUNT(DISTINCT business_unit) AS n FROM ${fq}.sec_v_keyuser_business_unit),
ver AS (
  SELECT MAX(t) AS last_change FROM (
    SELECT MAX(e.audit_updated_tmstmp) AS t FROM ${src}.t_sd_keyuser_by_entity e
      JOIN ${fq}.sec_v_caller_keyuser c ON c.keyuser = e.userid
    UNION ALL
    SELECT MAX(b.audit_updated_tmstmp) FROM ${src}.t_sd_keyuser_by_brand b
      JOIN ${fq}.sec_v_caller_keyuser c ON c.keyuser = b.userid
    UNION ALL
    SELECT MAX(u.audit_updated_tmstmp) FROM ${src}.t_sd_keyuser_by_business_unit u
      JOIN ${fq}.sec_v_caller_keyuser c ON c.keyuser = u.userid
  )
)
SELECT
  current_user() AS databricks_user,
  CASE WHEN m.n = 1 AND ku.n > 0 THEN m.finance_userid END AS finance_userid,  -- only when fully AUTHORIZED
  CASE
    WHEN m.n = 0 THEN 'UNMAPPED'
    WHEN m.n > 1 THEN 'AMBIGUOUS_MAPPING'
    WHEN ku.n = 0 THEN 'NO_ACTIVE_KEYUSER'
    ELSE 'AUTHORIZED'
  END AS resolution_status,
  ku.n AS keyuser_count,
  CASE WHEN m.n = 1 THEN ku.keyusers END AS keyusers,
  ent.n AS authorized_entity_count,
  brd.n AS authorized_brand_count,
  bus.n AS authorized_business_unit_count,
  substr(sha2(concat_ws('|', coalesce(ku.keyusers, ''), ent.n, brd.n, bus.n, coalesce(CAST(ver.last_change AS STRING), '')), 256), 1, 16)
    AS entitlement_version
FROM mapped m CROSS JOIN ku CROSS JOIN ent CROSS JOIN brd CROSS JOIN bus CROSS JOIN ver;

-- Reference views ---------------------------------------------------------------
CREATE OR REPLACE VIEW ${fq}.sec_v_entity_market_members
COMMENT 'Requested market nodes expanded to base entities via ${entity_hier}; one row per (market, entity).'
AS
SELECT
  UPPER(node_name) AS market_node_name,
  MAX(node_desc) AS market_description,
  base_node_name AS entity,
  MAX(base_node_desc) AS entity_description
FROM ${src}.t_md_hierarchy_base_node_links
WHERE hierarchy_name = '${entity_hier}'
  AND UPPER(node_name) IN (${market_list})
GROUP BY UPPER(node_name), base_node_name;

CREATE OR REPLACE VIEW ${fq}.sec_v_brand_labels
COMMENT 'Brand display labels; one row per brand.'
AS
SELECT base_node_name AS brand, MAX(base_node_desc) AS brand_name
FROM ${src}.t_md_hierarchy_base_node_links
WHERE hierarchy_name IN (${brand_hier_list})
  AND lower(trim(CAST(is_leaf AS STRING))) IN (${leaf_values})
GROUP BY base_node_name;

CREATE OR REPLACE VIEW ${fq}.sec_v_business_unit_labels
COMMENT 'Business-unit display labels; one row per business unit.'
AS
SELECT base_node_name AS business_unit, MAX(base_node_desc) AS business_unit_name
FROM ${src}.t_md_hierarchy_base_node_links
WHERE hierarchy_name = '${bu_hier}'
  AND lower(trim(CAST(is_leaf AS STRING))) IN (${leaf_values})
GROUP BY base_node_name;

CREATE OR REPLACE VIEW ${fq}.sec_v_daily_sales_measure_map
COMMENT 'Daily Sales (page ${page_id}) measure resolution from report configuration.'
AS
SELECT DISTINCT page_id, measure_name, measure_id
FROM ${src}.t_md_report_configuration
WHERE page_id = ${page_id}
  AND measure_name IN ('${measure_name}', 'DS_MTD_MtdActCY_vs_MtdActPY', 'DS_MTD_MtdFpCY');

-- Authorized Daily Sales (row security applied before any aggregation) ---------------
CREATE OR REPLACE VIEW ${fq}.sec_v_daily_sales_drilldown_authorized
COMMENT 'Daily Sales rows visible to current_user(): one keyuser must allow entity AND brand AND business unit. Actual data only (is_alt_data per config).'
AS
SELECT
  d.measure_id,
  d.reporting_date,
  d.account,
  d.business_unit,
  d.entity,
  d.brand,
  d.value,
  d.numerator,
  d.denominator,
  d.is_alt_data
FROM ${src}.t_dtm_daily_sales_report_drill_down d
WHERE lower(trim(CAST(d.is_alt_data AS STRING))) IN (${alt_data_values})
  AND EXISTS (
    SELECT 1
    FROM ${fq}.sec_v_keyuser_entity e
    JOIN ${fq}.sec_v_keyuser_brand b ON b.keyuser = e.keyuser
    JOIN ${fq}.sec_v_keyuser_business_unit u ON u.keyuser = e.keyuser
    WHERE e.entity = d.entity
      AND b.brand = d.brand
      AND u.business_unit = d.business_unit
  );

-- Semantic source for the Metric View (PoC slice) --------------------------------------
CREATE OR REPLACE VIEW ${fq}.sec_v_daily_sales_brand_performance_source
COMMENT 'Authorized ${period_name} ${measure_name}, account ${account_code}, actual data only, latest reporting date, expanded to requested markets. One row per (market, entity, brand, business unit).'
AS
WITH bdate AS (
  SELECT ${business_date_sql} AS business_date
),
actual_measure AS (
  SELECT DISTINCT measure_id, measure_name
  FROM ${fq}.sec_v_daily_sales_measure_map
  WHERE page_id = ${page_id} AND measure_name = '${measure_name}'
),
measure_guard AS (
  -- fail closed if configuration resolves to anything other than exactly one id
  SELECT COUNT(DISTINCT measure_id) = 1 AS ok FROM actual_measure
),
market_scope AS (
  SELECT m.market_node_name,
         COUNT(DISTINCT m.entity) AS market_entity_count,
         COUNT(DISTINCT a.entity) AS authorized_market_entity_count
  FROM ${fq}.sec_v_entity_market_members m
  LEFT JOIN (SELECT DISTINCT entity FROM ${fq}.sec_v_keyuser_entity) a
    ON a.entity = m.entity
  GROUP BY m.market_node_name
),
month_rows AS (
  SELECT d.measure_id, am.measure_name, d.reporting_date, d.account, d.business_unit, d.entity, d.brand, d.value
  FROM ${fq}.sec_v_daily_sales_drilldown_authorized d
  JOIN actual_measure am ON am.measure_id = d.measure_id
  CROSS JOIN measure_guard g
  CROSS JOIN bdate b
  WHERE g.ok
    AND d.account = '${account_code}'
    AND lower(trim(CAST(d.is_alt_data AS STRING))) IN (${alt_data_values})
    AND d.reporting_date >= trunc(b.business_date, 'MM')
    AND d.reporting_date <= b.business_date
    AND d.value IS NOT NULL
),
latest AS (
  SELECT MAX(reporting_date) AS reporting_date FROM month_rows
)
SELECT
  CAST(r.measure_id AS BIGINT) AS measure_id,
  r.measure_name,
  r.reporting_date,
  r.account,
  r.business_unit,
  r.entity,
  em.entity_description,
  r.brand,
  COALESCE(bl.brand_name, r.brand) AS brand_name,
  em.market_node_name,
  em.market_description,
  ms.market_entity_count,
  ms.authorized_market_entity_count,
  CAST(r.value AS DOUBLE) AS value
FROM month_rows r
JOIN latest l ON l.reporting_date = r.reporting_date
JOIN ${fq}.sec_v_entity_market_members em ON em.entity = r.entity
JOIN market_scope ms ON ms.market_node_name = em.market_node_name
LEFT JOIN ${fq}.sec_v_brand_labels bl ON bl.brand = r.brand;
