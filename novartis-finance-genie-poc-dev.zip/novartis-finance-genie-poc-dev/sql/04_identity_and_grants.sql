-- Identity seeding and least-privilege grants for the four Novartis DEV test users.
-- Placeholders: ${fq}, ${catalog}; identity seed rows and the per-user grant block are generated
-- by scripts/render.py from config/<target>.json.
-- IMPORTANT: CREATE OR REPLACE VIEW drops the view's grants. Re-run this file after every
-- re-run of 00c_current_state_views.sql, 01_security_views.sql or 02_metric_view.sql.
-- Test users receive SELECT on exactly two objects. No source/history table, src_cur_* view,
-- identity map or internal sec_* view is granted to anyone.

-- Seed (replace) the approved identity mappings: Databricks login (lower-case) -> Finance userid.
DELETE FROM ${fq}.sec_poc_identity_map WHERE source = 'POC_SEED';

INSERT INTO ${fq}.sec_poc_identity_map VALUES
${identity_seed_values};

-- Catalog / schema usage (repeated per user other than the deploying user). When usage_grants_by =
-- platform_team these are NOT executed here: they are rendered commented out and handed to the platform team.
-- @usage-grants-begin
GRANT USE CATALOG ON CATALOG ${catalog} TO `${principal}`;
GRANT USE SCHEMA ON SCHEMA ${fq} TO `${principal}`;
-- @usage-grants-end

-- Object grants (repeated per test user by scripts/render.py) ------------------------------
-- @persona-grants-begin
GRANT SELECT ON TABLE ${fq}.sec_v_current_user_finance_identity TO `${principal}`;
GRANT SELECT ON TABLE ${fq}.mv_brand_performance_actuals_mtd TO `${principal}`;
-- @persona-grants-end

-- Verify (as the deploying user)
SELECT databricks_user, finance_userid, identity_status, source, updated_at
FROM ${fq}.sec_poc_identity_map
ORDER BY databricks_user;

SHOW GRANTS ON TABLE ${fq}.mv_brand_performance_actuals_mtd;
SHOW GRANTS ON TABLE ${fq}.sec_v_current_user_finance_identity;

-- USE SCHEMA must be listed for all 4 users (granted by the platform team for the other 3)
SHOW GRANTS ON SCHEMA ${fq};
