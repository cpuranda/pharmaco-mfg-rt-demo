-- Independent expected results (oracle), run by the DEPLOYING user only (reads src_cur_* directly,
-- without current_user()). Compare each row with what that test user gets from 03_test_queries [totals]
-- and from Genie. Placeholders: ${fq}, ${src}, semantics from config.

WITH bdate AS (SELECT ${business_date_sql} AS business_date),
mapped AS (
  SELECT lower(databricks_user) AS databricks_user, finance_userid
  FROM ${fq}.sec_poc_identity_map
  WHERE identity_status = 'ACTIVE' AND source = 'POC_SEED'
),
ku AS (
  SELECT DISTINCT m.databricks_user, s.keyuser
  FROM mapped m
  JOIN ${src}.config_t_md_user_settings s ON s.userid = m.finance_userid
  JOIN ${src}.t_sd_user_profile p ON p.userid = s.userid
  JOIN ${src}.t_sd_keyuser_profile kp ON kp.keyuser = s.keyuser
  WHERE p.identity_status = '${active_status}'
    AND array_contains(transform(split(coalesce(p.applications, ''), '[;,]'), x -> upper(trim(x))), '${app_code}')
    AND s.keyuser IS NOT NULL AND trim(s.keyuser) <> ''
),
mid AS (
  SELECT DISTINCT measure_id FROM ${src}.t_md_report_configuration
  WHERE page_id = ${page_id} AND measure_name = '${measure_name}'
),
rows_ok AS (
  SELECT DISTINCT k.databricks_user, d.reporting_date, d.entity, d.brand, d.business_unit, d.value
  FROM ${src}.t_dtm_daily_sales_report_drill_down d
  JOIN mid ON mid.measure_id = d.measure_id
  CROSS JOIN ku k
  JOIN ${src}.t_sd_keyuser_by_entity e ON e.userid = k.keyuser AND e.entity = d.entity
  JOIN ${src}.t_sd_keyuser_by_brand b ON b.userid = k.keyuser AND b.brand = d.brand
  JOIN ${src}.t_sd_keyuser_by_business_unit u ON u.userid = k.keyuser AND u.business_unit = d.business_unit
  CROSS JOIN bdate
  WHERE (SELECT COUNT(*) FROM mid) = 1
    AND d.account = '${account_code}'
    AND lower(trim(CAST(d.is_alt_data AS STRING))) IN (${alt_data_values})
    AND d.reporting_date BETWEEN trunc(bdate.business_date, 'MM') AND bdate.business_date
    AND d.value IS NOT NULL
),
latest AS (SELECT databricks_user, MAX(reporting_date) AS reporting_date FROM rows_ok GROUP BY databricks_user),
europe AS (
  SELECT DISTINCT base_node_name AS entity FROM ${src}.t_md_hierarchy_base_node_links
  WHERE hierarchy_name = '${entity_hier}' AND UPPER(node_name) = 'EUROPE'
)
SELECT m.databricks_user, m.finance_userid, l.reporting_date,
       SUM(CAST(r.value AS DOUBLE)) AS expected_europe_mtd_actual_sales,
       COUNT(DISTINCT r.brand) AS expected_europe_brands
FROM mapped m
LEFT JOIN latest l ON l.databricks_user = m.databricks_user
LEFT JOIN rows_ok r ON r.databricks_user = m.databricks_user AND r.reporting_date = l.reporting_date
  AND r.entity IN (SELECT entity FROM europe)
GROUP BY m.databricks_user, m.finance_userid, l.reporting_date
ORDER BY m.databricks_user;
