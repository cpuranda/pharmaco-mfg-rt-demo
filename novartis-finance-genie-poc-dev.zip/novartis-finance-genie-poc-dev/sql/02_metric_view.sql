-- Metric View: the ONLY analytical Genie source for the PoC.
-- Placeholders: ${fq}, semantics from config/<target>.json
-- The source view is already current-user secured; this object is the semantic contract,
-- not the security boundary.

CREATE OR REPLACE VIEW ${fq}.mv_brand_performance_actuals_mtd
WITH METRICS
LANGUAGE YAML
AS $$
version: 1.1
comment: |
  Authorized ${period_name} Daily Sales brand performance (Actuals, MTD).
  Source rows are already filtered to the authenticated Unity Catalog user's Finance
  keyuser entitlements (entity, brand, business unit), account ${account_code},
  actual data only (is_alt_data filter), measure ${measure_name} resolved through report configuration, and
  the latest available ${period_name} reporting date (${period_note}).
  Each row belongs to one requested market; Europe overlaps Spain, Italy and France,
  so always group or filter by market and never add results across markets.
source: ${fq}.sec_v_daily_sales_brand_performance_source

dimensions:
  - name: market
    expr: market_node_name
    display_name: Market
    comment: Requested market hierarchy node (EUROPE, SPAIN, ITALY, FRANCE, JAPAN, CHINA) after authorized entity expansion.
    synonyms: ['region', 'country', 'geography', 'market node']

  - name: market_description
    expr: market_description
    display_name: Market Description
    synonyms: ['market name', 'region name', 'country name']

  - name: market_entity_count
    expr: market_entity_count
    display_name: Entities In Market
    comment: Number of base entities in the requested market hierarchy.

  - name: authorized_market_entity_count
    expr: authorized_market_entity_count
    display_name: Authorized Entities In Market
    comment: Number of the market's base entities the current user is entitled to. If lower than Entities In Market, the market result is PARTIAL and must be disclosed as such.
    synonyms: ['authorized scope', 'entity coverage']

  - name: entity
    expr: entity
    display_name: Entity ID

  - name: entity_description
    expr: entity_description
    display_name: Entity
    synonyms: ['legal entity', 'affiliate']

  - name: brand
    expr: brand
    display_name: Brand ID
    comment: Stable brand code; use as the second tie-breaker after brand_name.

  - name: brand_name
    expr: brand_name
    display_name: Brand
    synonyms: ['brand', 'product brand', 'product']

  - name: business_unit
    expr: business_unit
    display_name: Business Unit
    synonyms: ['BU']

  - name: reporting_date
    expr: reporting_date
    display_name: Reporting Date
    comment: Latest available ${period_name} reporting date; a single date per user scope.
    synonyms: ['as of date', 'data date', 'freshness']

  - name: account
    expr: account
    display_name: Account

  - name: measure_name
    expr: measure_name
    display_name: Source Measure
    comment: Finance report measure code (${measure_name}).

measures:
  - name: mtd_actual_sales
    expr: SUM(value)
    display_name: MTD Actual Sales
    comment: |
      ${period_mtd} Actuals from ${measure_name} at the latest reporting date
      within the current user's authorized scope. Default when no version is specified.
    synonyms: ['actual sales', 'actuals', 'MTD actual', 'MTD actual sales', 'sales performance', 'sales', 'performance']

  - name: authorized_brand_count
    expr: COUNT(DISTINCT brand)
    display_name: Authorized Brand Count
    comment: Number of distinct brands with authorized data in the result scope.
    synonyms: ['number of brands', 'brand count']

  - name: authorized_entity_with_data_count
    expr: COUNT(DISTINCT entity)
    display_name: Authorized Entities With Data
    comment: Number of distinct authorized entities that contributed data.
$$;

-- Compatibility checks (run as the operator after creation)
DESCRIBE TABLE EXTENDED ${fq}.mv_brand_performance_actuals_mtd AS JSON;
