-- Per-user checks. EACH of the four test users runs this file in the SQL editor while signed in
-- as themselves (the deploying user can run it too: they are one of the test users).
-- Results must differ per user exactly as their Finance keyuser entitlements differ.
-- Placeholders: fq (target schema), src (src_cur_ views), raw (physical lb_ history tables), market_list

-- [identity] Exactly one row; resolution_status must be AUTHORIZED and finance_userid = the mapped userid.
SELECT * FROM ${fq}.sec_v_current_user_finance_identity;

-- [semantic] Brand ranking per market through the Metric View (MEASURE only).
WITH ranked AS (
  SELECT market, brand_name, brand,
         MEASURE(mtd_actual_sales) AS mtd_actual_sales
  FROM ${fq}.mv_brand_performance_actuals_mtd
  WHERE market IN (${market_list})
  GROUP BY market, brand_name, brand
)
SELECT market, brand_name, brand, mtd_actual_sales,
       ROW_NUMBER() OVER (PARTITION BY market ORDER BY mtd_actual_sales DESC, brand_name, brand) AS best_rank,
       ROW_NUMBER() OVER (PARTITION BY market ORDER BY mtd_actual_sales ASC, brand_name, brand) AS worst_rank
FROM ranked
QUALIFY best_rank <= 5 OR worst_rank <= 5
ORDER BY market, best_rank;

-- [scope] Partial-coverage disclosure per market.
SELECT market, market_entity_count, authorized_market_entity_count,
       MEASURE(authorized_entity_with_data_count) AS entities_with_data,
       MEASURE(authorized_brand_count) AS brands
FROM ${fq}.mv_brand_performance_actuals_mtd
GROUP BY market, market_entity_count, authorized_market_entity_count
ORDER BY market;

-- [dates] Exactly one row: the latest reporting date in the demo period (${period_name}, ${period_note}).
SELECT reporting_date, MEASURE(mtd_actual_sales) AS mtd_actual_sales
FROM ${fq}.mv_brand_performance_actuals_mtd
GROUP BY reporting_date;

-- [filters] Only ${account_code} / ${measure_name}. Deploying user only (test users have no grant on the source view).
SELECT account, measure_name, COUNT(*) AS row_count
FROM ${fq}.sec_v_daily_sales_brand_performance_source
GROUP BY account, measure_name;

-- [totals] Europe total via MEASURE (compared to oracle).
SELECT current_user() AS databricks_user, market, MEASURE(mtd_actual_sales) AS mtd_actual_sales
FROM ${fq}.mv_brand_performance_actuals_mtd
WHERE market = 'EUROPE'
GROUP BY current_user(), market;

-- [denial] Each of these must FAIL with a permission error for every test user EXCEPT the deploying user
-- (who owns the target objects). If a test user CAN read the raw lb_*_history tables, report it: the Genie
-- space is still restricted to the Metric View, but free-form SQL could bypass the governed path.
SELECT COUNT(*) FROM ${raw}.t_dtm_daily_sales_report_drill_down;
SELECT COUNT(*) FROM ${raw}.t_sd_keyuser_by_brand;
SELECT COUNT(*) FROM ${src}.t_dtm_daily_sales_report_drill_down;
SELECT COUNT(*) FROM ${fq}.sec_poc_identity_map;
SELECT COUNT(*) FROM ${fq}.sec_v_user_keyuser;
SELECT COUNT(*) FROM ${fq}.sec_v_daily_sales_drilldown_authorized;
