-- PHASE 1 preflight (READ-ONLY) on the Lakebase-published source tables.
-- Run as the deploying user BEFORE anything is created. Nothing here writes.
-- ${src}.<table> resolves to the PHYSICAL tables, e.g. unifyplus_eu_finance.publish_fin_sync_poc.lb_<table>_history.
-- Expected column structure: docs/source_ddl_novartis_dev.sql.

-- P0: the exact login string Genie / UC will see for you. It must equal your identity_seed entry
--     (compared lower-case), e.g. PURANCH1@novartis.net.
SELECT current_user() AS my_login;

SHOW TABLES IN ${src};

DESCRIBE TABLE ${src}.config_t_md_page;
DESCRIBE TABLE ${src}.config_t_md_user_settings;
DESCRIBE TABLE ${src}.t_dtm_daily_sales_report_drill_down;
DESCRIBE TABLE ${src}.t_md_hierarchy_base_node_links;
DESCRIBE TABLE ${src}.t_md_report_configuration;
DESCRIBE TABLE ${src}.t_sd_keyuser_by_brand;
DESCRIBE TABLE ${src}.t_sd_keyuser_by_business_unit;
DESCRIBE TABLE ${src}.t_sd_keyuser_by_entity;
DESCRIBE TABLE ${src}.t_sd_keyuser_profile;
DESCRIBE TABLE ${src}.t_sd_user_profile;
