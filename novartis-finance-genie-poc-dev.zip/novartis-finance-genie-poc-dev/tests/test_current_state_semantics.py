"""Executes the GENERATED src_cur_* SQL on DuckDB against simulated Lakebase change feeds.

Proves the security-relevant behaviour: revoked grants disappear, updates appear once, key moves
remove the old key, unknown change types fail closed, ordering uses _pg_lsn then _sort_by.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import pytest

duckdb = pytest.importorskip("duckdb")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import render as rnd  # noqa: E402

CFG = json.loads((ROOT / "config/novartis_dev.json").read_text())
TGT = "f1common_eu_platform.chandra_fin_genie_poc"  # source lb_* copies and PoC views share this schema


def view_sql(table: str) -> str:
    sql = rnd.current_state_views(CFG)
    m = re.search(rf"(CREATE OR REPLACE VIEW {re.escape(TGT)}\.src_cur_{table}\n.*?;)\n", sql, re.S)
    assert m, table
    s = m.group(1)
    s = re.sub(r"\nCOMMENT '.*?'\n", "\n", s)            # DuckDB: no view COMMENT clause
    s = s.replace("SELECT * EXCEPT (", "SELECT * EXCLUDE (")  # DuckDB spelling
    return s.replace(f"{TGT}.", "tgt.")


@pytest.fixture()
def db():
    con = duckdb.connect()
    con.execute("CREATE SCHEMA tgt;")
    con.execute(
        "CREATE TABLE tgt.lb_t_sd_keyuser_by_brand_history (_pg_change_type VARCHAR, _pg_lsn BIGINT, _pg_xid INT,"
        " _timestamp TIMESTAMP, _sort_by BIGINT, userid VARCHAR, brand VARCHAR, audit_created_tmstmp TIMESTAMP,"
        " audit_updated_tmstmp TIMESTAMP)"
    )
    con.execute(
        "CREATE TABLE tgt.lb_config_t_md_user_settings_history (_pg_change_type VARCHAR, _pg_lsn BIGINT, _pg_xid INT,"
        " _timestamp TIMESTAMP, _sort_by BIGINT, userid VARCHAR, keyuser VARCHAR, setting_id VARCHAR)"
    )
    yield con
    con.close()


def ins(con, table, rows):
    for r in rows:
        ph = ", ".join("?" for _ in r)
        con.execute(f"INSERT INTO tgt.{table} VALUES ({ph})", list(r))


def brand(op, lsn, sort, ku, b):
    return (op, lsn, 1, "2026-11-01 00:00:00", sort, ku, b, None, None)


def test_brand_allowlist_current_state(db):
    ins(db, "lb_t_sd_keyuser_by_brand_history", [
        brand("insert", 10, 1, "KU001", "B01"),          # stays
        brand("insert", 10, 2, "KU001", "B02"),          # later deleted -> revoked
        brand("delete", 20, 1, "KU001", "B02"),
        brand("insert", 10, 3, "KU001", "B03"),          # key moved B03 -> B04
        brand("update_preimage", 30, 1, "KU001", "B03"),
        brand("update_postimage", 30, 2, "KU001", "B04"),
        brand("insert", 10, 4, "KU002", "B05"),          # deleted then re-granted -> present once
        brand("delete", 40, 1, "KU002", "B05"),
        brand("insert", 50, 1, "KU002", "B05"),
        brand("insert", 10, 5, "KU003", "B06"),          # unknown change type latest -> fail closed
        brand("truncate", 60, 1, "KU003", "B06"),
        brand("INSERT ", 10, 6, "KU004", "B07"),         # case / whitespace tolerant
    ])
    db.execute(view_sql("t_sd_keyuser_by_brand"))
    got = db.execute("SELECT userid, brand FROM tgt.src_cur_t_sd_keyuser_by_brand ORDER BY 1, 2").fetchall()
    assert got == [("KU001", "B01"), ("KU001", "B04"), ("KU002", "B05"), ("KU004", "B07")]
    cols = [d[0] for d in db.execute("SELECT * FROM tgt.src_cur_t_sd_keyuser_by_brand LIMIT 0").description]
    assert not any(c.startswith("_") for c in cols)


def test_same_key_update_keeps_post_image_even_on_full_tie(db):
    ins(db, "lb_config_t_md_user_settings_history", [
        ("insert", 10, 1, "2026-11-01", 1, "USR1", "KU001", "S1"),
        ("update_preimage", 20, 2, "2026-11-02", 5, "USR1", "KU001", "S1"),   # same _pg_lsn AND _sort_by
        ("update_postimage", 20, 2, "2026-11-02", 5, "USR1", "KU009", "S1"),
        ("insert", 10, 1, "2026-11-01", 2, "USR2", "KU002", "S1"),
        ("delete", 30, 3, "2026-11-03", 1, "USR2", None, None),              # key-only delete image
    ])
    db.execute(view_sql("config_t_md_user_settings"))
    got = db.execute("SELECT userid, keyuser FROM tgt.src_cur_config_t_md_user_settings ORDER BY 1").fetchall()
    assert got == [("USR1", "KU009")]   # USR2 deactivated even though the delete carried only the key


def test_ordering_is_lsn_first_then_sort_by(db):
    ins(db, "lb_t_sd_keyuser_by_brand_history", [
        brand("delete", 100, 1, "KU001", "B01"),        # higher LSN wins although _sort_by is lower
        brand("insert", 90, 999, "KU001", "B01"),
    ])
    db.execute(view_sql("t_sd_keyuser_by_brand"))
    assert db.execute("SELECT COUNT(*) FROM tgt.src_cur_t_sd_keyuser_by_brand").fetchone()[0] == 0
