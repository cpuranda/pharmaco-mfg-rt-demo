"""Tests render the real novartis_dev target in --preflight mode, which removes the deploy notebooks.
Restore the shipped (pending-preflight) build after the test session so the working tree stays intact."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="session", autouse=True)
def restore_shipped_build():
    yield
    cfg = (ROOT / "config/novartis_dev.json").read_text()
    mode = [] if '"preflight_confirmed": true' in cfg else ["--pending-preflight"]
    subprocess.run([sys.executable, str(ROOT / "scripts/render.py"), "novartis_dev", *mode], check=True, capture_output=True)
