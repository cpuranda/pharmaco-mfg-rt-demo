"""Static checks on the DEV SQL templates, rendered package and Genie space (no workspace needed)."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SEC = (ROOT / "sql/01_security_views.sql").read_text()
MV = (ROOT / "sql/02_metric_view.sql").read_text()
GRANTS = (ROOT / "sql/04_identity_and_grants.sql").read_text()
DDL = (ROOT / "docs/source_ddl_novartis_dev.sql").read_text()
CFG = json.loads((ROOT / "config/novartis_dev.json").read_text())
USERS = [
    "PURANCH1@novartis.net",
    "MUTAFMI1@novartis.net",
    "KOLLISA4@novartis.net",
    "MOHDHA1@novartis.net",
]
sys.path.insert(0, str(ROOT / "scripts"))
import render as rnd  # noqa: E402
import run_sql  # noqa: E402


def ddl_columns() -> dict[str, dict[str, str]]:
    out = {}
    for m in re.finditer(r"CREATE TABLE IF NOT EXISTS \S+\.lb_(\w+)_history \((.*?)\)\nUSING", DDL, re.S):
        cols = {}
        for line in m.group(2).splitlines():
            parts = line.strip().rstrip(",").split()
            if len(parts) >= 2:
                cols[parts[0]] = " ".join(parts[1:])
        out[m.group(1)] = cols
    return out


COLS = ddl_columns()


def first_word(stmt: str) -> str:
    return next(ln for ln in stmt.splitlines() if ln.strip() and not ln.strip().startswith("--")).split()[0].upper()


def render(target: str, *extra: str) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(ROOT / "scripts/render.py"), target, *extra], capture_output=True, text=True)


def complete_config(name: str, **over) -> Path:
    d = json.loads((ROOT / "config/novartis_dev.json").read_text())
    d.update({"target": name, "warehouse_id": "0000000000000000", "preflight_confirmed": True})
    d.update(over)
    p = ROOT / "config" / f"{name}.json"
    p.write_text(json.dumps(d))
    return p


@pytest.fixture()
def full_target():
    name = "zz_dev_full"
    p = complete_config(name)
    r = render(name)
    assert r.returncode == 0, r.stderr
    yield name
    p.unlink()
    shutil.rmtree(ROOT / "build" / name, ignore_errors=True)
    shutil.rmtree(ROOT / "genie" / "build" / name, ignore_errors=True)


# ---- configuration matches the request -------------------------------------------------------
def test_config_targets_requested_locations_and_users():
    assert CFG["host"] == "https://formulaone-eu-west-1-dev-common-workspace.cloud.databricks.com"
    assert (CFG["source_catalog"], CFG["source_schema"]) == ("f1common_eu_platform", "chandra_fin_genie_poc")  # user's copy
    assert (CFG["catalog"], CFG["schema"]) == ("f1common_eu_platform", "chandra_fin_genie_poc")
    assert CFG["create_schema"] is False and CFG["source_is_change_history"] is True
    assert [i["databricks_user"] for i in CFG["identity_seed"]] == USERS == CFG["persona_principals"]
    assert "demo_reentitlement" not in CFG and "app_name" not in CFG


def test_package_has_no_app_or_service_principal_artifacts():
    for p in ("backend", "frontend", "databricks.yml", ".persona_secrets", "tests/fevm"):
        assert not (ROOT / p).exists(), p
    for f in (ROOT / "sql").glob("*.sql"):
        t = f.read_text()
        assert "app_sp" not in t and "service_principal" not in t and "ent_persona" not in t, f.name


# ---- config keys vs the exact DEV DDL -----------------------------------------------------------
def test_ddl_has_all_ten_tables_and_cdf_metadata():
    assert sorted(COLS) == sorted(rnd.SOURCE_TABLES)
    for cols in COLS.values():
        for c in CFG["change_history"]["metadata_columns"]:
            assert c in cols


def test_history_keys_exist_in_ddl_and_cover_not_null_business_columns():
    meta = set(CFG["change_history"]["metadata_columns"])
    for t, keys in CFG["change_history"]["keys"].items():
        cols = COLS[t]
        assert all(k in cols for k in keys), (t, keys)
        not_null = [c for c, typ in cols.items() if "NOT NULL" in typ and c not in meta]
        if not_null:  # Postgres PK columns are NOT NULL: PK is a subset of these
            assert set(keys) <= set(not_null) or set(keys) == set(not_null), (t, keys, not_null)


def test_every_source_column_used_by_sql_exists_in_ddl():
    used = {
        "t_sd_user_profile": ["userid", "identity_status", "role", "country_name", "general_geo", "applications", "user_name", "alias"],
        "config_t_md_user_settings": ["userid", "keyuser"],
        "t_sd_keyuser_profile": ["keyuser"],
        "t_sd_keyuser_by_entity": ["userid", "entity", "audit_updated_tmstmp"],
        "t_sd_keyuser_by_brand": ["userid", "brand", "audit_updated_tmstmp"],
        "t_sd_keyuser_by_business_unit": ["userid", "business_unit", "audit_updated_tmstmp"],
        "t_md_hierarchy_base_node_links": ["hierarchy_name", "node_name", "node_desc", "node_level", "base_node_name", "base_node_desc", "is_leaf"],
        "t_md_report_configuration": ["page_id", "measure_name", "measure_id"],
        "t_dtm_daily_sales_report_drill_down": ["measure_id", "reporting_date", "account", "business_unit", "entity", "brand", "value", "numerator", "denominator", "is_alt_data"],
    }
    for t, cols in used.items():
        missing = [c for c in cols if c not in COLS[t]]
        assert not missing, (t, missing)


def test_string_flags_are_never_compared_to_integers():
    assert "STRING" in COLS["t_dtm_daily_sales_report_drill_down"]["is_alt_data"]
    assert "STRING" in COLS["t_md_hierarchy_base_node_links"]["is_leaf"]
    for sql in (SEC, (ROOT / "sql/03b_operator_oracle.sql").read_text()):
        assert not re.search(r"is_alt_data\s*=\s*0|is_leaf\s*=\s*1", sql)
    assert SEC.count("lower(trim(CAST(d.is_alt_data AS STRING))) IN (${alt_data_values})") == 2
    assert SEC.count("lower(trim(CAST(is_leaf AS STRING))) IN (${leaf_values})") == 2


# ---- render gates ------------------------------------------------------------------------------
def test_dev_config_has_mapping_and_no_placeholders_left():
    assert {i["databricks_user"]: i["finance_userid"] for i in CFG["identity_seed"]} == {
        "PURANCH1@novartis.net": "ALVARVI6",
        "MUTAFMI1@novartis.net": "AGARWVAC",
        "KOLLISA4@novartis.net": "ABADFR1",
        "MOHDHA1@novartis.net": "ABESH7",
    }
    assert CFG["warehouse_name"] == "DBSQL_89973" and CFG["warehouse_id"] is None
    assert not rnd.PLACEHOLDER.findall(json.dumps(CFG))


def test_final_render_waits_for_preflight_confirmation():
    assert CFG["preflight_confirmed"] is False
    r = render("novartis_dev")
    assert r.returncode != 0 and "preflight_confirmed" in r.stdout + r.stderr


def test_warehouse_name_is_resolved_by_bundle_lookup():
    name = "zz_dev_lookup"
    p = complete_config(name, warehouse_id=None)
    try:
        assert render(name).returncode == 0
        yml = (ROOT / "genie/build" / name / "genie_target.yml").read_text()
        assert 'warehouse_id:\n        lookup:\n          warehouse: "DBSQL_89973"' in yml
    finally:
        p.unlink()
        shutil.rmtree(ROOT / "build" / name, ignore_errors=True)
        shutil.rmtree(ROOT / "genie" / "build" / name, ignore_errors=True)


def test_warehouse_id_must_be_an_id_not_a_name():
    name = "zz_dev_badwh"
    p = complete_config(name, warehouse_id="DBSQL_89973")
    try:
        r = render(name)
        assert r.returncode != 0 and "16-hex" in r.stdout + r.stderr
    finally:
        p.unlink()


def test_preflight_checks_the_four_mapped_userids():
    assert render("novartis_dev", "--preflight").returncode == 0
    sem = (ROOT / "build/novartis_dev/rendered_sql/00d_preflight_semantics.sql").read_text()
    for u, f in (("kollisa4@novartis.net", "ABADFR1"), ("mohdha1@novartis.net", "ABESH7")):
        assert f"({u!r}, {f!r})".replace('"', "'") in sem
    assert "SELECT current_user() AS my_login" in (ROOT / "build/novartis_dev/rendered_sql/00_preflight.sql").read_text()


def test_final_render_refuses_unconfirmed_preflight():
    name = "zz_dev_unconfirmed"
    p = complete_config(name, preflight_confirmed=False)
    try:
        r = render(name)
        assert r.returncode != 0 and "preflight_confirmed" in r.stdout + r.stderr
    finally:
        p.unlink()


def test_shared_schema_requires_prefix_and_write_guard_blocks_source_tables():
    name = "zz_dev_noprefix"
    p = complete_config(name, source_table_prefix="", source_table_suffix="")
    try:
        r = render(name)
        assert r.returncode != 0 and "prefix/suffix is required" in r.stdout + r.stderr
    finally:
        p.unlink()
    for bad in (
        "INSERT INTO f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history VALUES (1)",
        "DROP TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history",
        "CREATE OR REPLACE VIEW f1common_eu_platform.other_schema.sec_v_x AS SELECT 1",
        "CREATE TABLE f1common_eu_platform.chandra_fin_genie_poc.my_table (a INT)",
    ):
        with pytest.raises(SystemExit):
            rnd.guard_writes("t.sql", bad, CFG)
    rnd.guard_writes("ok.sql", "CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_ok AS SELECT 1", CFG)


def test_ui_notebooks_are_generated_and_safe(full_target):
    nbdir = ROOT / "build" / full_target / "notebooks"
    names = sorted(f.name for f in nbdir.iterdir())
    assert names == [
        "01_preflight_raw_READ_ONLY.sql", "02_create_current_state_views.sql", "03_preflight_semantics_READ_ONLY.sql",
        "04_deploy_governed_objects.sql", "05_expected_results_DEPLOYER.sql", "06_per_user_validation.sql",
        "07_create_genie_space_OPTIONAL.py", "99_rollback.sql",
    ]
    for f in nbdir.glob("*.sql"):
        text = f.read_text()
        assert text.startswith("-- Databricks notebook source\n") and "-- COMMAND ----------" in text, f.name
        assert not re.findall(r"\$\{([a-z_]+)\}", text), f.name
        if "READ_ONLY" in f.name:
            assert not rnd.written_objects(text), f.name
    roll = (nbdir / "99_rollback.sql").read_text()
    drops = re.findall(r"DROP (?:VIEW|TABLE) IF EXISTS (\S+);", roll)
    assert len(drops) == 25 and not any(".lb_" in d for d in drops)
    assert "DROP TABLE IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_poc_identity_map" in roll
    assert roll.index("mv_brand_performance_actuals_mtd") < roll.index("src_cur_t_sd_user_profile")
    deploy = (nbdir / "04_deploy_governed_objects.sql").read_text()
    assert "PENDING PREFLIGHT" not in deploy  # full_target is confirmed
    import ast
    ast.parse((nbdir / "07_create_genie_space_OPTIONAL.py").read_text())
    ui = (ROOT / "build" / full_target / "GENIE_SPACE_UI_SETUP.md").read_text()
    assert "f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd" in ui and "Can run" in ui


def test_pending_preflight_render_marks_deploy_notebooks():
    r = render("novartis_dev", "--pending-preflight")
    assert r.returncode == 0 and "PENDING" in r.stdout
    nbdir = ROOT / "build/novartis_dev/notebooks"
    for n in ("04_deploy_governed_objects.sql", "05_expected_results_DEPLOYER.sql", "06_per_user_validation.sql"):
        assert "PENDING PREFLIGHT CONFIRMATION" in (nbdir / n).read_text()
    assert "PENDING" not in (nbdir / "01_preflight_raw_READ_ONLY.sql").read_text()


def test_preflight_render_works_with_placeholders_and_writes_nothing_else():
    r = render("novartis_dev", "--preflight")
    assert r.returncode == 0, r.stderr
    out = ROOT / "build/novartis_dev/rendered_sql"
    assert sorted(f.name for f in out.glob("*.sql")) == ["00_preflight.sql", "00c_current_state_views.sql", "00d_preflight_semantics.sql"]
    assert sorted(f.name for f in (out.parent / "notebooks").iterdir()) == [
        "01_preflight_raw_READ_ONLY.sql", "02_create_current_state_views.sql", "03_preflight_semantics_READ_ONLY.sql"]
    pre = (out / "00_preflight.sql").read_text()
    for stmt in run_sql.split_statements(pre):
        first = first_word(stmt)
        assert first in ("SELECT", "SHOW", "DESCRIBE", "WITH"), stmt[:80]  # read-only
    assert "f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history" in pre
    for u in USERS:
        assert f"SHOW GRANTS `{u}` ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc" in pre
    sem = (out / "00d_preflight_semantics.sql").read_text()
    assert not re.search(r"\blb_", re.sub(r"--[^\n]*", "", sem)) and "f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile" in sem
    for stmt in run_sql.split_statements(sem):
        assert first_word(stmt) in ("SELECT", "WITH"), stmt[:80]
    assert "'%purandare%'" in sem and "'%kollipara%'" in sem


def test_current_state_views_write_only_to_target_and_hide_metadata():
    assert render("novartis_dev", "--preflight").returncode == 0
    cs = (ROOT / "build/novartis_dev/rendered_sql/00c_current_state_views.sql").read_text()
    creates = re.findall(r"CREATE OR REPLACE VIEW (\S+)", cs)
    assert len(creates) == 10 and all(c.startswith("f1common_eu_platform.chandra_fin_genie_poc.src_cur_") for c in creates)
    assert cs.count("EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)") == 10
    assert "PARTITION BY userid, brand ORDER BY _pg_lsn DESC, _sort_by DESC" in cs
    assert "PARTITION BY userid ORDER BY" in cs  # config_t_md_user_settings: PK = userid (only NOT NULL column)
    assert cs.count("IN ('insert', 'update_postimage')") == 10


# ---- full (simulated complete) render ---------------------------------------------------------------
def test_full_render_security_path_reads_only_current_state(full_target):
    out = ROOT / "build" / full_target / "rendered_sql"
    sec = "\n".join(ln for ln in (out / "01_security_views.sql").read_text().splitlines() if not ln.strip().startswith("--"))
    assert re.search(r"\blb_", sec) is None and "_history" not in sec and "unifyplus_eu_finance" not in sec
    assert "f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_brand" in sec
    assert "CREATE SCHEMA" not in sec and "sec_v_poc_user_selector" not in sec and "aud_poc_request_audit" not in sec
    for f in out.glob("*.sql"):
        assert not re.findall(r"\$\{([a-z_]+)\}", f.read_text()), f.name
        code = re.sub(r"--[^\n]*", "", f.read_text())
        for c in re.findall(r"CREATE (?:OR REPLACE )?(?:VIEW|TABLE)(?: IF NOT EXISTS)? (\S+)", code):
            assert c.startswith("f1common_eu_platform.chandra_fin_genie_poc."), (f.name, c)
            assert re.match(r".*\.(src_cur_|sec_|mv_)", c), c


def test_full_render_grants_are_minimal_and_per_user(full_target):
    g = (ROOT / "build" / full_target / "rendered_sql/04_identity_and_grants.sql").read_text()
    for u in USERS:
        assert f"GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd TO `{u}`" in g
    objs = {o.rsplit(".", 1)[1] for o in re.findall(r"GRANT SELECT ON TABLE (\S+)", g)}
    assert objs == {"mv_brand_performance_actuals_mtd", "sec_v_current_user_finance_identity"}
    assert "unifyplus" not in g and "MODIFY" not in g
    assert "('puranch1@novartis.net', 'ALVARVI6', 'ACTIVE', true, 'POC_SEED'" in g


def test_usage_grants_are_left_to_the_platform_team(full_target):
    base = ROOT / "build" / full_target
    g = (base / "rendered_sql/04_identity_and_grants.sql").read_text()
    code = re.sub(r"--[^\n]*", "", g)
    assert "USE CATALOG" not in code and "USE SCHEMA" not in code  # nothing executable
    assert "-- GRANT USE CATALOG ON CATALOG f1common_eu_platform TO `MUTAFMI1@novartis.net`;" in g
    nb = (base / "notebooks/04_deploy_governed_objects.sql").read_text()
    cells = [c for c in nb.split("-- COMMAND ----------") if "MAGIC %md" not in c]
    assert not any(re.search(r"^\s*GRANT USE", c, re.M) for c in cells)
    assert "granted by the Novartis platform team (NOT run here)" in nb
    plat = (base / "PLATFORM_TEAM_GRANTS.sql").read_text()
    grants = re.findall(r"^GRANT (USE CATALOG|USE SCHEMA) ON \S+ \S+ TO `([^`]+)`;", plat, re.M)
    assert len(grants) == 6 and {u for _, u in grants} == set(USERS[1:])
    assert "PURANCH1@novartis.net`" not in plat


def test_full_render_genie_space_exposes_only_metric_view(full_target):
    space = json.loads((ROOT / "genie/build" / full_target / "space.geniespace.json").read_text())
    assert [t["identifier"] for t in space["data_sources"]["tables"]] == [
        "f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd"
    ]
    text = json.dumps(space)
    for raw in ("lb_", "src_cur_", "sec_v_daily_sales", "sec_poc_identity_map", "hls_streaming"):
        assert raw not in text
    yml = (ROOT / "genie/build" / full_target / "genie_target.yml").read_text()
    for u in USERS:
        assert f'level: CAN_RUN, user_name: "{u}"' in yml
    assert "formulaone-eu-west-1-dev-common-workspace" in yml
    wh = json.loads((ROOT / "build" / full_target / "warehouse_permissions.json").read_text())
    assert [a["user_name"] for a in wh["access_control_list"]] == USERS
    assert {a["permission_level"] for a in wh["access_control_list"]} == {"CAN_USE"}


def test_full_render_statements_parse_cleanly(full_target):
    keywords = ("CREATE", "INSERT", "DELETE", "SELECT", "GRANT", "SHOW", "DESCRIBE", "WITH")
    for f in sorted((ROOT / "build" / full_target / "rendered_sql").glob("*.sql")):
        for stmt in run_sql.split_statements(f.read_text()):
            first = next(ln for ln in stmt.splitlines() if ln.strip() and not ln.strip().startswith("--")).strip()
            assert first.upper().startswith(keywords), (f.name, first[:80])


def test_as_of_date_override():
    name = "zz_dev_asof"
    s = dict(CFG["semantics"], as_of_date="2026-11-30")
    p = complete_config(name, semantics=s)
    try:
        assert render(name).returncode == 0
        sec = (ROOT / "build" / name / "rendered_sql/01_security_views.sql").read_text()
        assert "SELECT DATE'2026-11-30' AS business_date" in sec
    finally:
        p.unlink()
        shutil.rmtree(ROOT / "build" / name, ignore_errors=True)
        shutil.rmtree(ROOT / "genie" / "build" / name, ignore_errors=True)


def test_default_business_date_is_amsterdam_today():
    """With as_of_date null the window follows today's Europe/Amsterdam month (live mode)."""
    name = "zz_dev_live"
    d = json.loads((ROOT / "config/novartis_dev.json").read_text())
    d["semantics"]["as_of_date"] = None
    p = complete_config(name, semantics=d["semantics"])
    try:
        assert render(name).returncode == 0
        sec = (ROOT / "build" / name / "rendered_sql/01_security_views.sql").read_text()
        assert "to_date(from_utc_timestamp(current_timestamp(), 'Europe/Amsterdam')) AS business_date" in sec
        assert "COMMENT 'Authorized current-month" in sec
        space = json.loads((ROOT / "genie/build" / name / "space.geniespace.json").read_text())
        assert "The latest available current-month reporting date is already enforced" in "".join(
            space["instructions"]["text_instructions"][0]["content"])
    finally:
        p.unlink()
        shutil.rmtree(ROOT / "build" / name, ignore_errors=True)
        shutil.rmtree(ROOT / "genie" / "build" / name, ignore_errors=True)


# ---- unchanged security invariants ---------------------------------------------------------------
def test_identity_comes_from_current_user_only():
    for name in ("sec_v_caller_keyuser", "sec_v_current_user_finance_identity"):
        m = re.search(rf"CREATE OR REPLACE VIEW \S+\.{name}\b(.*?)(?=\nCREATE |\Z)", SEC, re.S)
        assert m and "current_user()" in m.group(1)
    assert "selected" not in SEC.lower()


def test_allowlists_are_per_keyuser_and_metric_view_reads_only_secure_source():
    assert "b.keyuser = e.keyuser" in SEC and "u.keyuser = e.keyuser" in SEC
    assert "COUNT(DISTINCT measure_id) = 1" in SEC
    assert "source: ${fq}.sec_v_daily_sales_brand_performance_source" in MV
    yaml = MV.split("$$")[1]
    assert "${src}" not in yaml and "measure_id" not in yaml


def test_unknown_source_table_reference_is_rejected():
    with pytest.raises(SystemExit):
        rnd.resolve_sources("SELECT * FROM ${src}.t_sd_user_profle", CFG, raw=False)


def test_dev_demo_period_is_pinned_to_october_2026():
    """The DEV copy was synced from Lakebase in October 2026 and is static: the demo must not follow today's month."""
    assert CFG["semantics"]["as_of_date"] == "2026-10-31"
    assert render("novartis_dev", "--pending-preflight").returncode == 0
    nb = ROOT / "build/novartis_dev/notebooks"
    for f in ("04_deploy_governed_objects.sql", "05_expected_results_DEPLOYER.sql"):
        t = (nb / f).read_text()
        assert "DATE'2026-10-31'" in t
        assert "from_utc_timestamp(current_timestamp()" not in t
    space = json.loads((ROOT / "genie/build/novartis_dev/space.geniespace.json").read_text())
    text = "".join(space["instructions"]["text_instructions"][0]["content"])
    assert "fixed to October 2026 month-to-date" in text and "Never add date filters" in text
    assert "current-month" not in text
    assert space["data_sources"]["tables"][0]["description"][0].startswith("Authorized October 2026 (fixed demo period) Daily Sales")
