-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 04 - Deploy the governed objects
-- MAGIC
-- MAGIC > **PENDING PREFLIGHT CONFIRMATION.** Run notebooks 01-03 first and continue only if every gate passed; otherwise send the results back for a re-rendered package.
-- MAGIC
-- MAGIC Creates the identity bridge, the security views and the Metric View, seeds the 4 user mappings and the grants. Re-run this whole notebook after any re-run of notebook 02 (CREATE OR REPLACE VIEW drops grants).

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Security views

-- COMMAND ----------

-- Identity bridge --------------------------------------------------------------
CREATE TABLE IF NOT EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_poc_identity_map (
  databricks_user STRING NOT NULL COMMENT 'current_user() value (login 521 ID), stored lower-case',
  finance_userid STRING NOT NULL,
  identity_status STRING NOT NULL COMMENT 'ACTIVE | DISABLED',
  is_demo_user BOOLEAN NOT NULL,
  source STRING NOT NULL,
  valid_from TIMESTAMP,
  valid_to TIMESTAMP,
  updated_at TIMESTAMP NOT NULL
) COMMENT 'PoC identity bridge. Approved DEV test users only. Never granted to end users.';

-- COMMAND ----------

-- Internal: currently valid mappings
CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_identity_map_active
COMMENT 'Internal. Currently valid identity mappings.'
AS
SELECT lower(databricks_user) AS databricks_user, finance_userid
FROM f1common_eu_platform.chandra_fin_genie_poc.sec_poc_identity_map
WHERE identity_status = 'ACTIVE'
  AND (valid_from IS NULL OR valid_from <= current_timestamp())
  AND (valid_to IS NULL OR valid_to > current_timestamp());

-- COMMAND ----------

-- Internal (all users): identity -> Finance user -> keyuser
CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_user_keyuser
COMMENT 'Internal. Not granted to end users. Active Finance users with GENIE2 access and a registered keyuser.'
AS
SELECT DISTINCT
  i.databricks_user,
  i.finance_userid,
  s.keyuser,
  p.identity_status,
  p.role,
  p.country_name,
  p.general_geo
FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_identity_map_active i
JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_user_settings s
  ON s.userid = i.finance_userid
JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile p
  ON p.userid = s.userid
JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_profile kp
  ON kp.keyuser = s.keyuser
WHERE p.identity_status = 'Active'
  AND array_contains(transform(split(coalesce(p.applications, ''), '[;,]'), x -> upper(trim(x))), 'GENIE2')
  AND s.keyuser IS NOT NULL
  AND trim(s.keyuser) <> '';

-- COMMAND ----------

-- Internal (caller only): keyusers of the CURRENT user, only if the identity maps to
-- exactly one Finance userid.
CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser
COMMENT 'Internal. Keyusers of current_user(); empty unless exactly one Finance userid is mapped.'
AS
WITH mapped AS (
  SELECT COUNT(DISTINCT finance_userid) AS n
  FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_identity_map_active
  WHERE databricks_user = lower(current_user())
)
SELECT k.finance_userid, k.keyuser
FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_user_keyuser k
CROSS JOIN mapped m
WHERE k.databricks_user = lower(current_user())
  AND m.n = 1;

-- COMMAND ----------

-- Caller-scoped allowlists ------------------------------------------------------
CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_entity
COMMENT 'Entity allowlist of the current user (per keyuser).'
AS
SELECT DISTINCT c.finance_userid, c.keyuser, e.entity
FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser c
JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_entity e
  ON e.userid = c.keyuser;

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_brand
COMMENT 'Brand allowlist of the current user (per keyuser).'
AS
SELECT DISTINCT c.finance_userid, c.keyuser, b.brand
FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser c
JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_brand b
  ON b.userid = c.keyuser;

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_business_unit
COMMENT 'Business-unit allowlist of the current user (per keyuser).'
AS
SELECT DISTINCT c.finance_userid, c.keyuser, u.business_unit
FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser c
JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_business_unit u
  ON u.userid = c.keyuser;

-- COMMAND ----------

-- Identity self-check for each test user ("who am I in Finance?"), evaluated as current_user() ------
CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity
COMMENT 'Exactly one row: Finance identity of current_user(). resolution_status must be AUTHORIZED to proceed.'
AS
WITH mapped AS (
  SELECT COUNT(DISTINCT finance_userid) AS n, MIN(finance_userid) AS finance_userid
  FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_identity_map_active
  WHERE databricks_user = lower(current_user())
),
ku AS (
  SELECT COUNT(DISTINCT keyuser) AS n, array_join(array_sort(collect_set(keyuser)), ',') AS keyusers
  FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser
),
ent AS (SELECT COUNT(DISTINCT entity) AS n FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_entity),
brd AS (SELECT COUNT(DISTINCT brand) AS n FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_brand),
bus AS (SELECT COUNT(DISTINCT business_unit) AS n FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_business_unit),
ver AS (
  SELECT MAX(t) AS last_change FROM (
    SELECT MAX(e.audit_updated_tmstmp) AS t FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_entity e
      JOIN f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser c ON c.keyuser = e.userid
    UNION ALL
    SELECT MAX(b.audit_updated_tmstmp) FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_brand b
      JOIN f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser c ON c.keyuser = b.userid
    UNION ALL
    SELECT MAX(u.audit_updated_tmstmp) FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_business_unit u
      JOIN f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser c ON c.keyuser = u.userid
  )
)
SELECT
  current_user() AS databricks_user,
  CASE WHEN m.n = 1 AND ku.n > 0 THEN m.finance_userid END AS finance_userid,  -- only when fully AUTHORIZED
  CASE
    WHEN m.n = 0 THEN 'UNMAPPED'
    WHEN m.n > 1 THEN 'AMBIGUOUS_MAPPING'
    WHEN ku.n = 0 THEN 'NO_ACTIVE_KEYUSER'
    ELSE 'AUTHORIZED'
  END AS resolution_status,
  ku.n AS keyuser_count,
  CASE WHEN m.n = 1 THEN ku.keyusers END AS keyusers,
  ent.n AS authorized_entity_count,
  brd.n AS authorized_brand_count,
  bus.n AS authorized_business_unit_count,
  substr(sha2(concat_ws('|', coalesce(ku.keyusers, ''), ent.n, brd.n, bus.n, coalesce(CAST(ver.last_change AS STRING), '')), 256), 1, 16)
    AS entitlement_version
FROM mapped m CROSS JOIN ku CROSS JOIN ent CROSS JOIN brd CROSS JOIN bus CROSS JOIN ver;

-- COMMAND ----------

-- Reference views ---------------------------------------------------------------
CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_entity_market_members
COMMENT 'Requested market nodes expanded to base entities via ENTITY_HIER_REP; one row per (market, entity).'
AS
SELECT
  UPPER(node_name) AS market_node_name,
  MAX(node_desc) AS market_description,
  base_node_name AS entity,
  MAX(base_node_desc) AS entity_description
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_hierarchy_base_node_links
WHERE hierarchy_name = 'ENTITY_HIER_REP'
  AND UPPER(node_name) IN ('EUROPE', 'SPAIN', 'ITALY', 'FRANCE', 'JAPAN', 'CHINA')
GROUP BY UPPER(node_name), base_node_name;

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_brand_labels
COMMENT 'Brand display labels; one row per brand.'
AS
SELECT base_node_name AS brand, MAX(base_node_desc) AS brand_name
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_hierarchy_base_node_links
WHERE hierarchy_name IN ('BRAND_GENIE_UNIFIED_HIER_REP', 'BRAND_EXT_TA_HIERARCHY_REP')
  AND lower(trim(CAST(is_leaf AS STRING))) IN ('1')
GROUP BY base_node_name;

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_business_unit_labels
COMMENT 'Business-unit display labels; one row per business unit.'
AS
SELECT base_node_name AS business_unit, MAX(base_node_desc) AS business_unit_name
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_hierarchy_base_node_links
WHERE hierarchy_name = 'BUSINESS_UNIT_HIER_REP'
  AND lower(trim(CAST(is_leaf AS STRING))) IN ('1')
GROUP BY base_node_name;

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_measure_map
COMMENT 'Daily Sales (page 10000) measure resolution from report configuration.'
AS
SELECT DISTINCT page_id, measure_name, measure_id
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_report_configuration
WHERE page_id = 10000
  AND measure_name IN ('DS_MTD_MtdActCY', 'DS_MTD_MtdActCY_vs_MtdActPY', 'DS_MTD_MtdFpCY');

-- COMMAND ----------

-- Authorized Daily Sales (row security applied before any aggregation) ---------------
CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_drilldown_authorized
COMMENT 'Daily Sales rows visible to current_user(): one keyuser must allow entity AND brand AND business unit. Actual data only (is_alt_data per config).'
AS
SELECT
  d.measure_id,
  d.reporting_date,
  d.account,
  d.business_unit,
  d.entity,
  d.brand,
  d.value,
  d.numerator,
  d.denominator,
  d.is_alt_data
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_dtm_daily_sales_report_drill_down d
WHERE lower(trim(CAST(d.is_alt_data AS STRING))) IN ('0')
  AND EXISTS (
    SELECT 1
    FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_entity e
    JOIN f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_brand b ON b.keyuser = e.keyuser
    JOIN f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_business_unit u ON u.keyuser = e.keyuser
    WHERE e.entity = d.entity
      AND b.brand = d.brand
      AND u.business_unit = d.business_unit
  );

-- COMMAND ----------

-- Semantic source for the Metric View (PoC slice) --------------------------------------
CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_brand_performance_source
COMMENT 'Authorized October 2026 DS_MTD_MtdActCY, account IS01_100, actual data only, latest reporting date, expanded to requested markets. One row per (market, entity, brand, business unit).'
AS
WITH bdate AS (
  SELECT DATE'2026-10-31' AS business_date
),
actual_measure AS (
  SELECT DISTINCT measure_id, measure_name
  FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_measure_map
  WHERE page_id = 10000 AND measure_name = 'DS_MTD_MtdActCY'
),
measure_guard AS (
  -- fail closed if configuration resolves to anything other than exactly one id
  SELECT COUNT(DISTINCT measure_id) = 1 AS ok FROM actual_measure
),
market_scope AS (
  SELECT m.market_node_name,
         COUNT(DISTINCT m.entity) AS market_entity_count,
         COUNT(DISTINCT a.entity) AS authorized_market_entity_count
  FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_entity_market_members m
  LEFT JOIN (SELECT DISTINCT entity FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_entity) a
    ON a.entity = m.entity
  GROUP BY m.market_node_name
),
month_rows AS (
  SELECT d.measure_id, am.measure_name, d.reporting_date, d.account, d.business_unit, d.entity, d.brand, d.value
  FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_drilldown_authorized d
  JOIN actual_measure am ON am.measure_id = d.measure_id
  CROSS JOIN measure_guard g
  CROSS JOIN bdate b
  WHERE g.ok
    AND d.account = 'IS01_100'
    AND lower(trim(CAST(d.is_alt_data AS STRING))) IN ('0')
    AND d.reporting_date >= trunc(b.business_date, 'MM')
    AND d.reporting_date <= b.business_date
    AND d.value IS NOT NULL
),
latest AS (
  SELECT MAX(reporting_date) AS reporting_date FROM month_rows
)
SELECT
  CAST(r.measure_id AS BIGINT) AS measure_id,
  r.measure_name,
  r.reporting_date,
  r.account,
  r.business_unit,
  r.entity,
  em.entity_description,
  r.brand,
  COALESCE(bl.brand_name, r.brand) AS brand_name,
  em.market_node_name,
  em.market_description,
  ms.market_entity_count,
  ms.authorized_market_entity_count,
  CAST(r.value AS DOUBLE) AS value
FROM month_rows r
JOIN latest l ON l.reporting_date = r.reporting_date
JOIN f1common_eu_platform.chandra_fin_genie_poc.sec_v_entity_market_members em ON em.entity = r.entity
JOIN market_scope ms ON ms.market_node_name = em.market_node_name
LEFT JOIN f1common_eu_platform.chandra_fin_genie_poc.sec_v_brand_labels bl ON bl.brand = r.brand;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Metric View (the only Genie source)

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd
WITH METRICS
LANGUAGE YAML
AS $$
version: 1.1
comment: |
  Authorized October 2026 Daily Sales brand performance (Actuals, MTD).
  Source rows are already filtered to the authenticated Unity Catalog user's Finance
  keyuser entitlements (entity, brand, business unit), account IS01_100,
  actual data only (is_alt_data filter), measure DS_MTD_MtdActCY resolved through report configuration, and
  the latest available October 2026 reporting date (fixed demo period, as_of_date 2026-10-31).
  Each row belongs to one requested market; Europe overlaps Spain, Italy and France,
  so always group or filter by market and never add results across markets.
source: f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_brand_performance_source

dimensions:
  - name: market
    expr: market_node_name
    display_name: Market
    comment: Requested market hierarchy node (EUROPE, SPAIN, ITALY, FRANCE, JAPAN, CHINA) after authorized entity expansion.
    synonyms: ['region', 'country', 'geography', 'market node']

  - name: market_description
    expr: market_description
    display_name: Market Description
    synonyms: ['market name', 'region name', 'country name']

  - name: market_entity_count
    expr: market_entity_count
    display_name: Entities In Market
    comment: Number of base entities in the requested market hierarchy.

  - name: authorized_market_entity_count
    expr: authorized_market_entity_count
    display_name: Authorized Entities In Market
    comment: Number of the market's base entities the current user is entitled to. If lower than Entities In Market, the market result is PARTIAL and must be disclosed as such.
    synonyms: ['authorized scope', 'entity coverage']

  - name: entity
    expr: entity
    display_name: Entity ID

  - name: entity_description
    expr: entity_description
    display_name: Entity
    synonyms: ['legal entity', 'affiliate']

  - name: brand
    expr: brand
    display_name: Brand ID
    comment: Stable brand code; use as the second tie-breaker after brand_name.

  - name: brand_name
    expr: brand_name
    display_name: Brand
    synonyms: ['brand', 'product brand', 'product']

  - name: business_unit
    expr: business_unit
    display_name: Business Unit
    synonyms: ['BU']

  - name: reporting_date
    expr: reporting_date
    display_name: Reporting Date
    comment: Latest available October 2026 reporting date; a single date per user scope.
    synonyms: ['as of date', 'data date', 'freshness']

  - name: account
    expr: account
    display_name: Account

  - name: measure_name
    expr: measure_name
    display_name: Source Measure
    comment: Finance report measure code (DS_MTD_MtdActCY).

measures:
  - name: mtd_actual_sales
    expr: SUM(value)
    display_name: MTD Actual Sales
    comment: |
      October 2026 month-to-date Actuals from DS_MTD_MtdActCY at the latest reporting date
      within the current user's authorized scope. Default when no version is specified.
    synonyms: ['actual sales', 'actuals', 'MTD actual', 'MTD actual sales', 'sales performance', 'sales', 'performance']

  - name: authorized_brand_count
    expr: COUNT(DISTINCT brand)
    display_name: Authorized Brand Count
    comment: Number of distinct brands with authorized data in the result scope.
    synonyms: ['number of brands', 'brand count']

  - name: authorized_entity_with_data_count
    expr: COUNT(DISTINCT entity)
    display_name: Authorized Entities With Data
    comment: Number of distinct authorized entities that contributed data.
$$;

-- COMMAND ----------

-- Compatibility checks (run as the operator after creation)
DESCRIBE TABLE EXTENDED f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd AS JSON;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Identity seed and object grants

-- COMMAND ----------

-- Seed (replace) the approved identity mappings: Databricks login (lower-case) -> Finance userid.
DELETE FROM f1common_eu_platform.chandra_fin_genie_poc.sec_poc_identity_map WHERE source = 'POC_SEED';

-- COMMAND ----------

INSERT INTO f1common_eu_platform.chandra_fin_genie_poc.sec_poc_identity_map VALUES
  ('puranch1@novartis.net', 'ALVARVI6', 'ACTIVE', true, 'POC_SEED', current_timestamp(), NULL, current_timestamp()),
  ('mutafmi1@novartis.net', 'AGARWVAC', 'ACTIVE', true, 'POC_SEED', current_timestamp(), NULL, current_timestamp()),
  ('kollisa4@novartis.net', 'ABADFR1', 'ACTIVE', true, 'POC_SEED', current_timestamp(), NULL, current_timestamp()),
  ('mohdha1@novartis.net', 'ABESH7', 'ACTIVE', true, 'POC_SEED', current_timestamp(), NULL, current_timestamp());

-- COMMAND ----------

-- Object grants (repeated per test user by scripts/render.py) ------------------------------
GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity TO `PURANCH1@novartis.net`;

-- COMMAND ----------

GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd TO `PURANCH1@novartis.net`;

-- COMMAND ----------

GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity TO `MUTAFMI1@novartis.net`;

-- COMMAND ----------

GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd TO `MUTAFMI1@novartis.net`;

-- COMMAND ----------

GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity TO `KOLLISA4@novartis.net`;

-- COMMAND ----------

GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd TO `KOLLISA4@novartis.net`;

-- COMMAND ----------

GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity TO `MOHDHA1@novartis.net`;

-- COMMAND ----------

GRANT SELECT ON TABLE f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd TO `MOHDHA1@novartis.net`;

-- COMMAND ----------

-- Verify (as the deploying user)
SELECT databricks_user, finance_userid, identity_status, source, updated_at
FROM f1common_eu_platform.chandra_fin_genie_poc.sec_poc_identity_map
ORDER BY databricks_user;

-- COMMAND ----------

SHOW GRANTS ON TABLE f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd;

-- COMMAND ----------

SHOW GRANTS ON TABLE f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity;

-- COMMAND ----------

-- USE SCHEMA must be listed for all 4 users (granted by the platform team for the other 3)
SHOW GRANTS ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Catalog / schema usage — granted by the Novartis platform team (NOT run here)
-- MAGIC
-- MAGIC These statements are intentionally not executed in this notebook. Send `PLATFORM_TEAM_GRANTS.sql` to the platform team; the users can query only after these grants exist (check with the SHOW GRANTS ON SCHEMA cell above).
-- MAGIC
-- MAGIC ```sql
-- MAGIC GRANT USE CATALOG ON CATALOG f1common_eu_platform TO `MUTAFMI1@novartis.net`;
-- MAGIC GRANT USE SCHEMA ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc TO `MUTAFMI1@novartis.net`;
-- MAGIC GRANT USE CATALOG ON CATALOG f1common_eu_platform TO `KOLLISA4@novartis.net`;
-- MAGIC GRANT USE SCHEMA ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc TO `KOLLISA4@novartis.net`;
-- MAGIC GRANT USE CATALOG ON CATALOG f1common_eu_platform TO `MOHDHA1@novartis.net`;
-- MAGIC GRANT USE SCHEMA ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc TO `MOHDHA1@novartis.net`;
-- MAGIC ```
