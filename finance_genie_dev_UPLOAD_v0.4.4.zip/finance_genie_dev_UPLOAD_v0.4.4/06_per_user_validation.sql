-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 06 - Per-user validation (EACH test user, signed in as themselves)
-- MAGIC
-- MAGIC > **PENDING PREFLIGHT CONFIRMATION.** Run notebooks 01-03 first and continue only if every gate passed; otherwise send the results back for a re-rendered package.
-- MAGIC
-- MAGIC Share this notebook with the 4 users (Can run). [identity] must be AUTHORIZED with their userid; [totals] EUROPE = their row in notebook 05; the [denial] cells must FAIL (except for the deploying user, who owns the objects). Run cell by cell so the expected failures do not stop the run.

-- COMMAND ----------

-- [identity] Exactly one row; resolution_status must be AUTHORIZED and finance_userid = the mapped userid.
SELECT * FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity;

-- COMMAND ----------

-- [semantic] Brand ranking per market through the Metric View (MEASURE only).
WITH ranked AS (
  SELECT market, brand_name, brand,
         MEASURE(mtd_actual_sales) AS mtd_actual_sales
  FROM f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd
  WHERE market IN ('EUROPE', 'SPAIN', 'ITALY', 'FRANCE', 'JAPAN', 'CHINA')
  GROUP BY market, brand_name, brand
)
SELECT market, brand_name, brand, mtd_actual_sales,
       ROW_NUMBER() OVER (PARTITION BY market ORDER BY mtd_actual_sales DESC, brand_name, brand) AS best_rank,
       ROW_NUMBER() OVER (PARTITION BY market ORDER BY mtd_actual_sales ASC, brand_name, brand) AS worst_rank
FROM ranked
QUALIFY best_rank <= 5 OR worst_rank <= 5
ORDER BY market, best_rank;

-- COMMAND ----------

-- [scope] Partial-coverage disclosure per market.
SELECT market, market_entity_count, authorized_market_entity_count,
       MEASURE(authorized_entity_with_data_count) AS entities_with_data,
       MEASURE(authorized_brand_count) AS brands
FROM f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd
GROUP BY market, market_entity_count, authorized_market_entity_count
ORDER BY market;

-- COMMAND ----------

-- [dates] Exactly one row: the latest reporting date in the demo period (October 2026, fixed demo period, as_of_date 2026-10-31).
SELECT reporting_date, MEASURE(mtd_actual_sales) AS mtd_actual_sales
FROM f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd
GROUP BY reporting_date;

-- COMMAND ----------

-- [filters] Only IS01_100 / DS_MTD_MtdActCY. Deploying user only (test users have no grant on the source view).
SELECT account, measure_name, COUNT(*) AS row_count
FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_brand_performance_source
GROUP BY account, measure_name;

-- COMMAND ----------

-- [totals] Europe total via MEASURE (compared to oracle).
SELECT current_user() AS databricks_user, market, MEASURE(mtd_actual_sales) AS mtd_actual_sales
FROM f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd
WHERE market = 'EUROPE'
GROUP BY current_user(), market;

-- COMMAND ----------

-- [denial] Each of these must FAIL with a permission error for every test user EXCEPT the deploying user
-- (who owns the target objects). If a test user CAN read the raw lb_*_history tables, report it: the Genie
-- space is still restricted to the Metric View, but free-form SQL could bypass the governed path.
SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history;

-- COMMAND ----------

SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history;

-- COMMAND ----------

SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_dtm_daily_sales_report_drill_down;

-- COMMAND ----------

SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.sec_poc_identity_map;

-- COMMAND ----------

SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_user_keyuser;

-- COMMAND ----------

SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_drilldown_authorized;
