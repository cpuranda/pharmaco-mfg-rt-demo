-- Request to the Novartis platform team — Novartis DEV Finance Genie PoC
-- Please grant catalog / schema usage to these 3 test users: MUTAFMI1@novartis.net, KOLLISA4@novartis.net, MOHDHA1@novartis.net.
-- Usage only: no SELECT, MODIFY or other data privilege (table-level SELECT on two PoC views is granted by the PoC owner).
-- Optional, if not yet granted: CAN USE on SQL warehouse DBSQL_89973 for the same users.

GRANT USE CATALOG ON CATALOG f1common_eu_platform TO `MUTAFMI1@novartis.net`;
GRANT USE SCHEMA ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc TO `MUTAFMI1@novartis.net`;
GRANT USE CATALOG ON CATALOG f1common_eu_platform TO `KOLLISA4@novartis.net`;
GRANT USE SCHEMA ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc TO `KOLLISA4@novartis.net`;
GRANT USE CATALOG ON CATALOG f1common_eu_platform TO `MOHDHA1@novartis.net`;
GRANT USE SCHEMA ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc TO `MOHDHA1@novartis.net`;
