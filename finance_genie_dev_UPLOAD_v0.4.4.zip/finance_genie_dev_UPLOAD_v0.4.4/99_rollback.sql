-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 99 - Rollback (drops only PoC objects)
-- MAGIC
-- MAGIC Delete the Genie space in the UI first. The lb_*_history tables are never touched.

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.mv_brand_performance_actuals_mtd;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_brand_performance_source;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_drilldown_authorized;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_daily_sales_measure_map;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_business_unit_labels;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_brand_labels;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_entity_market_members;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_business_unit;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_brand;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_keyuser_entity;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_caller_keyuser;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_user_keyuser;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_v_identity_map_active;

-- COMMAND ----------

DROP TABLE IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.sec_poc_identity_map;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_dtm_daily_sales_report_drill_down;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_report_configuration;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_profile;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_business_unit;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_brand;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_entity;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_user_settings;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_page;

-- COMMAND ----------

DROP VIEW IF EXISTS f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_hierarchy_base_node_links;
