-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 01 - Preflight on the raw history tables (READ-ONLY)
-- MAGIC
-- MAGIC Attach to SQL warehouse **DBSQL_89973** and **Run all**. Nothing is written; reads `f1common_eu_platform.chandra_fin_genie_poc.lb_*_history`.
-- MAGIC
-- MAGIC **Gates:** P0 = your login exactly as in the mapping; P1 = 10 tables; P2 only insert / update_preimage / update_postimage / delete; **P3 all zeros**; P5 record the grants.

-- COMMAND ----------

-- P0: the exact login string Genie / UC will see for you. It must equal your identity_seed entry
--     (compared lower-case), e.g. PURANCH1@novartis.net.
SELECT current_user() AS my_login;

-- COMMAND ----------

SHOW TABLES IN f1common_eu_platform.chandra_fin_genie_poc;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history;

-- COMMAND ----------

DESCRIBE TABLE f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history;

-- COMMAND ----------

-- ===== GENERATED source checks (read-only) =====
-- P1: all 10 expected physical tables exist
SELECT table_name, table_type FROM f1common_eu_platform.information_schema.tables
WHERE table_schema = 'chandra_fin_genie_poc' AND table_name IN ('lb_t_md_hierarchy_base_node_links_history', 'lb_config_t_md_page_history', 'lb_config_t_md_user_settings_history', 'lb_t_sd_keyuser_by_entity_history', 'lb_t_sd_keyuser_by_brand_history', 'lb_t_sd_keyuser_by_business_unit_history', 'lb_t_sd_keyuser_profile_history', 'lb_t_sd_user_profile_history', 'lb_t_md_report_configuration_history', 'lb_t_dtm_daily_sales_report_drill_down_history')
ORDER BY table_name;   -- expect 10 rows

-- P2: change-type distribution per table. Every value must be one of: 'insert', 'update_postimage', 'update_preimage', 'delete'
--     (any other value is treated as NOT live -> rows disappear; tell the Databricks team)
SELECT 't_md_hierarchy_base_node_links' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 'config_t_md_page' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 'config_t_md_user_settings' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 't_sd_keyuser_by_entity' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 't_sd_keyuser_by_brand' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 't_sd_keyuser_by_business_unit' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 't_sd_keyuser_profile' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 't_sd_user_profile' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 't_md_report_configuration' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history GROUP BY lower(trim(_pg_change_type))
UNION ALL
SELECT 't_dtm_daily_sales_report_drill_down' AS logical_table, lower(trim(_pg_change_type)) AS change_type, COUNT(*) AS change_rows, MIN(_timestamp) AS first_change, MAX(_timestamp) AS last_change FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history GROUP BY lower(trim(_pg_change_type))
ORDER BY logical_table, change_type;

-- COMMAND ----------

-- P3: key validation per table. ALL of these columns must be 0, otherwise the key in
--     config change_history.keys is wrong for that table (do NOT deploy; adjust and re-render):
--     keys_with_multiple_live_inserts: a key inserted twice without a delete in between -> key too narrow
--     key_null_in_delete_or_preimage: delete/pre-image rows with a NULL key column -> key too wide
--     unknown_change_type_rows: change types outside the configured lists
--     full_order_ties: two changes of one key with the same ordering columns (ambiguous latest)
SELECT 't_md_hierarchy_base_node_links' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT rn FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history GROUP BY rn
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (rn IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT rn, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY rn, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 'config_t_md_page' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT page_id FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history GROUP BY page_id
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (page_id IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT page_id, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY page_id, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 'config_t_md_user_settings' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT userid FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history GROUP BY userid
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (userid IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT userid, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY userid, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 't_sd_keyuser_by_entity' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT userid, entity FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history GROUP BY userid, entity
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (userid IS NULL OR entity IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT userid, entity, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY userid, entity, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 't_sd_keyuser_by_brand' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT userid, brand FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history GROUP BY userid, brand
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (userid IS NULL OR brand IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT userid, brand, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY userid, brand, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 't_sd_keyuser_by_business_unit' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT userid, business_unit FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history GROUP BY userid, business_unit
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (userid IS NULL OR business_unit IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT userid, business_unit, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY userid, business_unit, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 't_sd_keyuser_profile' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT keyuser FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history GROUP BY keyuser
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (keyuser IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT keyuser, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY keyuser, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 't_sd_user_profile' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT userid FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history GROUP BY userid
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (userid IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT userid, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY userid, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 't_md_report_configuration' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT page_id, report_id, report_object, column_id FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history GROUP BY page_id, report_id, report_object, column_id
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (page_id IS NULL OR report_id IS NULL OR report_object IS NULL OR column_id IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT page_id, report_id, report_object, column_id, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY page_id, report_id, report_object, column_id, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
UNION ALL
SELECT 't_dtm_daily_sales_report_drill_down' AS logical_table,
  (SELECT COUNT(*) FROM (SELECT measure_id, reporting_date, account, business_unit, entity, brand, is_alt_data FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history GROUP BY measure_id, reporting_date, account, business_unit, entity, brand, is_alt_data
     HAVING SUM(CASE WHEN lower(trim(_pg_change_type)) = 'insert' THEN 1 ELSE 0 END) - SUM(CASE WHEN lower(trim(_pg_change_type)) IN ('delete') THEN 1 ELSE 0 END) > 1))
    AS keys_with_multiple_live_inserts,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history WHERE lower(trim(_pg_change_type)) IN ('delete', 'update_preimage') AND (measure_id IS NULL OR reporting_date IS NULL OR account IS NULL OR business_unit IS NULL OR entity IS NULL OR brand IS NULL OR is_alt_data IS NULL))
    AS key_null_in_delete_or_preimage,
  (SELECT COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history WHERE lower(trim(_pg_change_type)) IS NULL OR lower(trim(_pg_change_type)) NOT IN ('insert', 'update_postimage', 'update_preimage', 'delete')) AS unknown_change_type_rows,
  (SELECT COUNT(*) FROM (SELECT measure_id, reporting_date, account, business_unit, entity, brand, is_alt_data, _pg_lsn, _sort_by FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history
     WHERE lower(trim(_pg_change_type)) NOT IN ('update_preimage')
     GROUP BY measure_id, reporting_date, account, business_unit, entity, brand, is_alt_data, _pg_lsn, _sort_by HAVING COUNT(*) > 1)) AS full_order_ties
ORDER BY logical_table;

-- COMMAND ----------

-- P4: history volume vs current state (informational: rows > keys means several versions per key)
SELECT 't_md_hierarchy_base_node_links' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT rn) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history
UNION ALL
SELECT 'config_t_md_page' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT page_id) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history
UNION ALL
SELECT 'config_t_md_user_settings' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT userid) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history
UNION ALL
SELECT 't_sd_keyuser_by_entity' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT userid, entity) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history
UNION ALL
SELECT 't_sd_keyuser_by_brand' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT userid, brand) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history
UNION ALL
SELECT 't_sd_keyuser_by_business_unit' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT userid, business_unit) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history
UNION ALL
SELECT 't_sd_keyuser_profile' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT keyuser) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history
UNION ALL
SELECT 't_sd_user_profile' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT userid) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history
UNION ALL
SELECT 't_md_report_configuration' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT page_id, report_id, report_object, column_id) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history
UNION ALL
SELECT 't_dtm_daily_sales_report_drill_down' AS logical_table, COUNT(*) AS change_rows, COUNT(DISTINCT measure_id, reporting_date, account, business_unit, entity, brand, is_alt_data) AS distinct_keys FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history
ORDER BY logical_table;

-- COMMAND ----------

-- P5: existing grants of the test users on the SOURCE schema. If a test user can SELECT the raw
--     lb_*_history tables directly, a free-form Genie / SQL session could bypass the governed path.
--     The Genie space itself only uses the Metric View; record these findings for the security review.
SHOW GRANTS `PURANCH1@novartis.net` ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc;

-- COMMAND ----------

SHOW GRANTS `MUTAFMI1@novartis.net` ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc;

-- COMMAND ----------

SHOW GRANTS `KOLLISA4@novartis.net` ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc;

-- COMMAND ----------

SHOW GRANTS `MOHDHA1@novartis.net` ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc;

-- COMMAND ----------

SHOW GRANTS ON SCHEMA f1common_eu_platform.chandra_fin_genie_poc;   -- target schema: deploying user needs CREATE TABLE + CREATE VIEW (+ MANAGE to grant);
