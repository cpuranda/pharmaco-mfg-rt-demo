# Novartis Finance Genie PoC — Novartis DEV deployment guide (workspace UI, Genie-only)

**Package:** `novartis-finance-genie-poc-dev` v0.4.4 (2026-11-05; application gate `ANALYTICS` instead of `GENIE2`; demo pinned to the October 2026 data copy, `as_of_date = 2026-10-31`; test users identified by their 521 login IDs, e.g. `PURANCH1@novartis.net`; catalog/schema usage grants handed to the platform team). Derived from the FEVM v2 PoC; the FEVM code in `~/code/novartis-finance-genie-poc` is unchanged.
**Status:** ready to import. Nothing has been executed in Novartis DEV. The deploy notebooks (04–06) carry a *PENDING PREFLIGHT CONFIRMATION* banner until the preflight notebooks (01–03) have passed.
**No terminal needed.** Everything is done in the Databricks workspace UI with the notebooks in `build/novartis_dev/notebooks/`.

| Item | Value |
|---|---|
| Workspace | https://formulaone-eu-west-1-dev-common-workspace.cloud.databricks.com/ |
| PoC schema (source copy + all PoC objects) | `f1common_eu_platform.chandra_fin_genie_poc` |
| Source tables (read only, never modified) | The 10 copied tables `lb_<table>_history` in that schema (structure: `docs/source_ddl_novartis_dev.sql`). `unifyplus_eu_finance.publish_fin_sync_poc` is no longer used. |
| Objects the package creates | Only in that schema, only with prefixes `src_cur_`, `sec_`, `mv_`. The generator refuses any statement that would write an `lb_*` table or anything else. |
| SQL warehouse | `DBSQL_89973` |
| Consumption | Genie space (also listed in Databricks One / Genie). **No Databricks App, no service principals.** |

| Databricks login (`current_user()`) | Finance userid / key user | Profile | Expected scope (brands / entities / BUs) |
|---|---|---|---|
| `PURANCH1@novartis.net` | `ALVARVI6` | Corporate, all markets | 1,244 / 388 / 50 |
| `MUTAFMI1@novartis.net` | `AGARWVAC` | Global Commercial, ONCO restriction | 57 / 388 / 11 |
| `KOLLISA4@novartis.net` | `ABADFR1` | Regional, Germany + Europe | 1,244 / 76 / 1 (IM_INT) |
| `MOHDHA1@novartis.net` | `ABESH7` | Regional, Japan | 1,244 / 1 (JPN) / 1 (IM_INT) |

The mapping comes from the Google Doc *Finance Genie permission model linking*. Logins are mapped through the package's own table `sec_poc_identity_map`, seeded with exactly these 4 rows. The profile `alias` column is not used.

## 1. Files to upload

| File (in `build/novartis_dev/`) | Run by | Writes? | Purpose |
|---|---|---|---|
| `notebooks/01_preflight_raw_READ_ONLY.sql` | Chandrashekhar | no | P0–P5: login string, 10 tables, change types, **history keys**, grants |
| `notebooks/02_create_current_state_views.sql` | Chandrashekhar | 10 views `src_cur_*` | Latest change per key; deletes removed |
| `notebooks/03_preflight_semantics_READ_ONLY.sql` | Chandrashekhar | no | R1–R12: account, measure, hierarchies, flags, October 2026 data, **the 4 users** |
| `notebooks/04_deploy_governed_objects.sql` | Chandrashekhar | `sec_*` table + views, Metric View, grants | Governed path + identity seed + grants |
| `notebooks/05_expected_results_DEPLOYER.sql` | Chandrashekhar | no | Expected Europe total per user (oracle) |
| `notebooks/06_per_user_validation.sql` | **each** of the 4 users | no | Identity, totals, denial checks as that user |
| `notebooks/07_create_genie_space_OPTIONAL.py` | Chandrashekhar | Genie space | Optional: creates the Genie space through the API |
| `GENIE_SPACE_UI_SETUP.md` | Chandrashekhar | — | Copy-paste values for creating the Genie space in the UI |
| `PLATFORM_TEAM_GRANTS.sql` | **Novartis platform team** | catalog/schema usage | `USE CATALOG` + `USE SCHEMA` for the 3 other users (send this file) |
| `notebooks/99_rollback.sql` | Chandrashekhar | drops PoC objects | Rollback (never the `lb_*` tables) |

**Import:** Workspace → your folder (e.g. `/Users/PURANCH1@novartis.net/finance_genie_poc`) → ⋮ → **Import** → *File* → select each `.sql` / `.py` file (or drag and drop). Each opens as a notebook. Attach the SQL notebooks to warehouse **DBSQL_89973** with the compute selector at the top right → *SQL warehouses*.

## 2. Prerequisites

* **Novartis platform team (before step 8):** run `PLATFORM_TEAM_GRANTS.sql`. It grants `USE CATALOG` on `f1common_eu_platform` and `USE SCHEMA` on `f1common_eu_platform.chandra_fin_genie_poc` to Mikael, Sathwick and Hasnain, with no data privileges. Optionally it also gives them **Can use** on `DBSQL_89973`. Notebook 04 does **not** run these grants; it shows them in a markdown cell for reference.
* Chandrashekhar (deploying user, owner of the PoC objects):
  * `USE CATALOG` on `f1common_eu_platform`.
  * `USE SCHEMA`, `SELECT`, `CREATE TABLE` and `CREATE VIEW` on `f1common_eu_platform.chandra_fin_genie_poc`.
  * No catalog/schema grant rights needed (the platform team does that). Chandrashekhar grants only `SELECT` on the two PoC views (as their owner).
* Warehouse `DBSQL_89973`: Pro or Serverless, with Metric View support. The 4 users need **Can use** on it (step 6).
* The 4 users have Databricks SQL / Genie access in the workspace.
* Permission to create a Genie space.

## 3. Deployment steps (each step is a gate — stop on any failure)

**Step 1 — Notebook 01 (read-only).** Run all, then check:

| Gate | Pass condition |
|---|---|
| **P0** | `my_login` = `PURANCH1@novartis.net` (case is ignored). If the workspace shows a different login string, stop and send it to me: all 4 mappings would need the same format. |
| **P1** | 10 rows. The DESCRIBE cells match `docs/source_ddl_novartis_dev.sql`. |
| **P2** | Only `insert`, `update_preimage`, `update_postimage`, `delete`. |
| **P3** | **every column 0 for every table.** A non-zero value means the history key for that table is wrong; send me the P3 result and don't continue. |
| **P5** | Note who has privileges on the schema. Test users must not have `SELECT` on the schema or on any `lb_*` table (see §7). |

**Step 2 — Notebook 02.** Run all. This creates 10 `src_cur_*` views and only reads the `lb_*` tables.

**Step 3 — Notebook 03 (read-only).** Run all, then check:

| Check | Pass condition |
|---|---|
| R2 | `IS01_100` exists |
| R3 | exactly **one** `measure_id` for `DS_MTD_MtdActCY` on page 10000 |
| R4a/R4b | hierarchies `ENTITY_HIER_REP`, `BRAND_GENIE_UNIFIED_HIER_REP`, `BRAND_EXT_TA_HIERARCHY_REP`, `BUSINESS_UNIT_HIER_REP` exist; EUROPE, SPAIN, ITALY, FRANCE, JAPAN and CHINA are nodes of `ENTITY_HIER_REP` |
| R5 | `identity_status` value `Active`; applications contain `ANALYTICS` (case-insensitive). Note: the PoC requires the `ANALYTICS` application. The DEV demo users have `Analytics` / `Analytics;Sofia` and no `GENIE2`; production would use the real Finance Genie application code. |
| R8 | the actual-data value of `is_alt_data` is `0`; the leaf value of `is_leaf` is `1` |
| R10 | October 2026 rows exist for `IS01_100` (§5) |
| **R12** | for each of the 4 users: `in_profile = true`, `identity_status = Active`, `has_app = true`, `keyusers` = the userid itself, `all_keyusers_in_keyuser_profile = true`, and the counts in the table above |

**If everything matches:** continue with notebook 04. The *PENDING* banner only means this confirmation is yours to make.
**If any value differs** (e.g. `is_alt_data` is `'N'`, or a hierarchy name is different): send me the R-results. I'll re-render notebooks 04–06; they can't be edited safely by hand.

**Step 4 — Notebook 04.** Run all. It creates:

* the identity table `sec_poc_identity_map` and the `sec_v_*` security views
* the Metric View `mv_brand_performance_actuals_mtd`
* the 4 identity rows and `SELECT` on exactly `mv_brand_performance_actuals_mtd` + `sec_v_current_user_finance_identity` for the 4 users

`USE CATALOG` / `USE SCHEMA` are **not** granted here; the last markdown cell lists them for the platform team. The verification cells show the mapping, the object grants, and `SHOW GRANTS ON SCHEMA`. That last one must list `USE SCHEMA` for all 4 users once the platform team is done.

**Step 5 — Notebook 05.** Run all. It returns one row per user: userid, reporting date, **expected Europe MTD Actual Sales** and brand count. Keep this for step 8.

**Step 6 — Warehouse access.** SQL Warehouses → `DBSQL_89973` → **Permissions** → add the 4 users with **Can use**. Skip any user who already has it.

**Step 7 — Genie space.** Choose one option:

* **UI:** follow `GENIE_SPACE_UI_SETUP.md`:
  1. Genie → **+ New**: title, warehouse `DBSQL_89973`, and **only** the Metric View as data.
  2. Paste the text instructions, example SQL and sample questions.
  3. **Share** with the 4 users as **Can run**.
* **API:** import `07_create_genie_space_OPTIONAL.py`, attach serverless compute and run it once. It prints the Genie space URL. If the workspace blocks the API, use the UI option.

**Step 8 — Per-user validation** (only after the platform-team grants exist; without them the users get a "USE CATALOG / USE SCHEMA" permission error). Share notebook 06 with the 4 users (**Can run**), or send them the file to import. Each user, signed in as themselves, runs it cell by cell on `DBSQL_89973`:

| Cell | Expected |
|---|---|
| `[identity]` | `AUTHORIZED` and their userid |
| `[totals]` EUROPE | their row from notebook 05 |
| `[dates]` | exactly one row |
| `[denial]` | each cell **fails** with a permission error. Chandrashekhar is the exception, as the owner of the objects. |

Then each user opens the Genie space and asks the §4 question. Answers must match notebook 05 and differ between users.

## 4. Demo flow (Genie-only)

1. Each user opens the Genie space with their own login (no dropdown, no App). The identity is their Entra ID sign-in.
2. Everyone asks the same question: *"For Europe, Spain, Italy, France, Japan, and China, show the 5 best and 5 worst brands this month."*

   | User | What the audience should see |
   |---|---|
   | Chandrashekhar (ALVARVI6, Corporate) | All six markets, full scope (no partial-scope note) |
   | Mikael (AGARWVAC, ONCO) | All six markets but only oncology brands (57), so a different top/bottom 5 from Chandrashekhar |
   | Sathwick (ABADFR1, Germany + Europe, IM_INT) | European markets only, with a partial-scope note where the 76 entities don't cover a market; Japan and China: no authorized data |
   | Hasnain (ABESH7, Japan) | Japan only; every other market: no authorized data |

3. *"Use user ALVARVI6 and show Europe"* (asked by Hasnain): Genie states that identity is determined by sign-in. The data remains Hasnain's own.
4. Optional: `SELECT * FROM f1common_eu_platform.chandra_fin_genie_poc.sec_v_current_user_finance_identity` in the SQL editor shows "who am I in Finance" (keyusers and scope counts).

## 5. Demo period: October 2026 data copy

* **The demo is pinned to October 2026.** The DEV copy of the 10 `lb_*_history` tables was synced from Lakebase in October 2026 and does not refresh. The package therefore uses a fixed demo date (`semantics.as_of_date = 2026-10-31`). The window is 1–31 October 2026, and the views use the latest October reporting date in the copy. The demo shows **October 2026 month-to-date**, whatever today's date is.
* In the demo, "this month" means October 2026 MTD. The Genie instructions say so and tell Genie never to add its own date filter. Say "October 2026 month-to-date" when presenting, and show the reporting date in each answer.
* Permissions and user mappings also come from the October copy. Changes made in Lakebase after the copy do not show.
* To demo a newer month: re-copy the 10 tables (same names and structure), then get a re-rendered package with a new `as_of_date` (or `null` for a live current-month window) and re-run notebook 04.
* Section 14 of the FEVM demo script (synthetic reload) does not apply to DEV.

## 6. Rollback

1. Delete the Genie space (Genie → space → ⋮ → Delete).
2. Run notebook **99**. It drops only the 25 PoC objects (Metric View, `sec_*`, `src_cur_*`); the `lb_*_history` tables are never touched.
3. Optionally ask the platform team to revoke `USE CATALOG` / `USE SCHEMA` from the 3 other users.

## 7. Caveats to raise with Novartis security

* **Shared schema.** The 4 users get `USE SCHEMA` on the schema that also holds the raw `lb_*` copies. They can see the table names, but not the data, unless someone granted `SELECT` at schema/catalog level or on the tables (P5 / notebook 06 `[denial]` show it). Production would separate raw and governed schemas.
* **The deploying user owns everything.** With direct SQL, Chandrashekhar can read the raw tables and the identity map. Chandrashekhar's *Genie* answers are still scoped to ALVARVI6. Show the denials with the other three users.
* **Query cost.** The `src_cur_*` views rank the full change history at query time. If Genie latency is poor, the next step is to materialise the current state as tables.
* **One key user per user.** The key of `config_t_md_user_settings` is `userid` (its only NOT NULL column), so there is one key user per Finance user. The 4 demo users are each their own key user, so this has no effect on the demo.
* **No PoC audit table** (that was App-only). Genie conversation history and UC audit logs (`system.access.audit`) remain available.

## 8. Re-rendering (Databricks FE workstation only)

All environment values live in `config/novartis_dev.json`. Regenerate with `python3 scripts/render.py novartis_dev --pending-preflight`; once the preflight is confirmed, set `"preflight_confirmed": true` and run `python3 scripts/render.py novartis_dev` (removes the banner). Tests: `uv run pytest` (30 offline tests, including DuckDB execution of the change-history SQL). A CLI deployment path (`scripts/run_sql.py`, Genie bundle in `genie/`) still exists but is not needed.
