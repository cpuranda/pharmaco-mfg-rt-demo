-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 02 - Create the current-state views
-- MAGIC
-- MAGIC Creates 10 views `src_cur_*` (latest change per key; deletes removed). Views only; the lb_* tables are never modified.

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_hierarchy_base_node_links
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history (latest change per key: rn; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY rn ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_hierarchy_base_node_links_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_page
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history (latest change per key: page_id; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY page_id ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_page_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_user_settings
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history (latest change per key: userid; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY userid ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_config_t_md_user_settings_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_entity
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history (latest change per key: userid, entity; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY userid, entity ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_entity_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_brand
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history (latest change per key: userid, brand; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY userid, brand ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_brand_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_business_unit
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history (latest change per key: userid, business_unit; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY userid, business_unit ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_by_business_unit_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_profile
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history (latest change per key: keyuser; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY keyuser ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_keyuser_profile_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history (latest change per key: userid; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY userid ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_sd_user_profile_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_report_configuration
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history (latest change per key: page_id, report_id, report_object, column_id; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY page_id, report_id, report_object, column_id ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_md_report_configuration_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');

-- COMMAND ----------

CREATE OR REPLACE VIEW f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_dtm_daily_sales_report_drill_down
COMMENT 'Current state of f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history (latest change per key: measure_id, reporting_date, account, business_unit, entity, brand, is_alt_data; deleted / moved keys removed).'
AS
SELECT * EXCEPT (_pg_change_type, _pg_lsn, _pg_xid, _timestamp, _sort_by, _cs_rn)
FROM (
  SELECT *, ROW_NUMBER() OVER (PARTITION BY measure_id, reporting_date, account, business_unit, entity, brand, is_alt_data ORDER BY _pg_lsn DESC, _sort_by DESC, CASE WHEN lower(trim(_pg_change_type)) IN ('update_preimage') THEN 1 ELSE 0 END) AS _cs_rn
  FROM f1common_eu_platform.chandra_fin_genie_poc.lb_t_dtm_daily_sales_report_drill_down_history
)
WHERE _cs_rn = 1
  AND lower(trim(_pg_change_type)) IN ('insert', 'update_postimage');
