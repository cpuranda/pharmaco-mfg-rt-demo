-- Databricks notebook source
-- MAGIC %md
-- MAGIC # 03 - Preflight on current state (READ-ONLY)
-- MAGIC
-- MAGIC Confirm R2 account, R3 exactly one measure id, R4 hierarchies and markets, R5 status / application, R8 flag values, R10 November data present, and **R12 the 4 mapped users** (in profile, Active, GENIE2, own keyuser, expected scope counts).

-- COMMAND ----------

-- R1: keyuser tables are keyed by keyuser codes (column "userid" holds the keyuser) that exist in user settings
SELECT 'by_entity' AS src, COUNT(DISTINCT e.userid) AS keys,
       COUNT(DISTINCT CASE WHEN s.keyuser IS NOT NULL THEN e.userid END) AS keys_matching_settings_keyuser,
       COUNT(DISTINCT CASE WHEN p.userid IS NOT NULL THEN e.userid END) AS keys_matching_finance_userid
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_entity e
LEFT JOIN (SELECT DISTINCT keyuser FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_user_settings) s ON s.keyuser = e.userid
LEFT JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile p ON p.userid = e.userid;

-- COMMAND ----------

-- R2: account values (expect IS01_100)
SELECT account, COUNT(*) AS row_count
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_dtm_daily_sales_report_drill_down
GROUP BY account
ORDER BY row_count DESC
LIMIT 50;

-- COMMAND ----------

-- R3: measure ids resolved through report configuration (expect exactly one id for DS_MTD_MtdActCY on page 10000)
SELECT page_id, measure_name, measure_id, COUNT(*) AS config_rows
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_report_configuration
WHERE measure_name LIKE 'DS_MTD%'
GROUP BY page_id, measure_name, measure_id
ORDER BY page_id, measure_name, measure_id;

-- COMMAND ----------

-- R4a: hierarchy names (expect ENTITY_HIER_REP, 'BRAND_GENIE_UNIFIED_HIER_REP', 'BRAND_EXT_TA_HIERARCHY_REP', BUSINESS_UNIT_HIER_REP)
SELECT hierarchy_name, COUNT(*) AS link_rows, COUNT(DISTINCT base_node_name) AS base_nodes
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_hierarchy_base_node_links
GROUP BY hierarchy_name
ORDER BY hierarchy_name;

-- COMMAND ----------

-- R4b: market nodes in any hierarchy (expect all of 'EUROPE', 'SPAIN', 'ITALY', 'FRANCE', 'JAPAN', 'CHINA' in ENTITY_HIER_REP)
SELECT hierarchy_name, node_name, node_desc, node_level, COUNT(DISTINCT base_node_name) AS base_entities
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_hierarchy_base_node_links
WHERE UPPER(node_name) IN ('EUROPE', 'SPAIN', 'ITALY', 'FRANCE', 'JAPAN', 'CHINA') OR UPPER(node_desc) IN ('EUROPE', 'SPAIN', 'ITALY', 'FRANCE', 'JAPAN', 'CHINA')
GROUP BY hierarchy_name, node_name, node_desc, node_level
ORDER BY hierarchy_name, node_level, node_name;

-- COMMAND ----------

-- R5: identity_status / applications values (expect 'Active' and an application list containing GENIE2)
SELECT identity_status, applications, COUNT(*) AS users
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile
GROUP BY identity_status, applications
ORDER BY users DESC
LIMIT 50;

-- COMMAND ----------

-- R7: Finance users with more than one keyuser in user settings (resolved as an additive union)
SELECT userid, COUNT(DISTINCT keyuser) AS keyusers
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_user_settings
WHERE keyuser IS NOT NULL
GROUP BY userid
HAVING COUNT(DISTINCT keyuser) > 1
LIMIT 50;

-- COMMAND ----------

-- R8: STRING flag values (DEV DDL: is_alt_data and is_leaf are STRING). Confirm the values that mean
--     "actual (not alternative) data" = '0' and "leaf node" = '1'.
SELECT 'is_alt_data' AS flag, is_alt_data AS value, COUNT(*) AS row_count
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_dtm_daily_sales_report_drill_down GROUP BY is_alt_data
UNION ALL
SELECT 'is_leaf', is_leaf, COUNT(*) FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_md_hierarchy_base_node_links GROUP BY is_leaf
ORDER BY flag, row_count DESC;

-- COMMAND ----------

-- R9: candidate Finance userids for the four test users: active GENIE2 users with a registered keyuser
--     and the size of their scope. Pick four with DIFFERENT scopes (e.g. partial Europe, global, one BU, two keyusers).
WITH ku AS (
  SELECT DISTINCT s.userid, s.keyuser
  FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_user_settings s
  JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_profile kp ON kp.keyuser = s.keyuser
  WHERE s.keyuser IS NOT NULL AND trim(s.keyuser) <> ''
),
ent AS (SELECT ku.userid, COUNT(DISTINCT e.entity) AS n FROM ku JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_entity e ON e.userid = ku.keyuser GROUP BY ku.userid),
brd AS (SELECT ku.userid, COUNT(DISTINCT b.brand) AS n FROM ku JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_brand b ON b.userid = ku.keyuser GROUP BY ku.userid),
bus AS (SELECT ku.userid, COUNT(DISTINCT u.business_unit) AS n FROM ku JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_business_unit u ON u.userid = ku.keyuser GROUP BY ku.userid),
kl AS (SELECT userid, array_join(array_sort(collect_set(keyuser)), ',') AS keyusers FROM ku GROUP BY userid)
SELECT p.userid, p.user_name, p.role, p.country_name, kl.keyusers,
       COALESCE(ent.n, 0) AS entities, COALESCE(brd.n, 0) AS brands, COALESCE(bus.n, 0) AS business_units
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile p
JOIN kl ON kl.userid = p.userid
LEFT JOIN ent ON ent.userid = p.userid
LEFT JOIN brd ON brd.userid = p.userid
LEFT JOIN bus ON bus.userid = p.userid
WHERE p.identity_status = 'Active'
  AND array_contains(transform(split(coalesce(p.applications, ''), '[;,]'), x -> upper(trim(x))), 'GENIE2')
ORDER BY entities DESC, brands DESC
LIMIT 100;

-- COMMAND ----------

-- R10: data freshness by month (the demo shows the CURRENT Europe/Amsterdam month; for November 2026 there must be
--      November rows for IS01_100). If the latest month is older, set semantics.as_of_date (see guide §5).
SELECT date_trunc('MONTH', reporting_date) AS month, COUNT(*) AS row_count,
       MIN(reporting_date) AS first_date, MAX(reporting_date) AS last_date
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_dtm_daily_sales_report_drill_down
WHERE account = 'IS01_100'
GROUP BY date_trunc('MONTH', reporting_date)
ORDER BY month DESC
LIMIT 6;

-- COMMAND ----------

-- R11: are the test users themselves present in the Finance user profile (matched on their login ID and name tokens)?
SELECT userid, user_name, alias, identity_status, applications, role, country_name
FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile
WHERE lower(coalesce(user_name, '')) LIKE '%puranch1%' OR lower(coalesce(alias, '')) LIKE '%puranch1%'
   OR lower(coalesce(user_name, '')) LIKE '%chandrashekhar%' OR lower(coalesce(alias, '')) LIKE '%chandrashekhar%'
   OR lower(coalesce(user_name, '')) LIKE '%purandare%' OR lower(coalesce(alias, '')) LIKE '%purandare%'
   OR lower(coalesce(user_name, '')) LIKE '%mutafmi1%' OR lower(coalesce(alias, '')) LIKE '%mutafmi1%'
   OR lower(coalesce(user_name, '')) LIKE '%mikael%' OR lower(coalesce(alias, '')) LIKE '%mikael%'
   OR lower(coalesce(user_name, '')) LIKE '%mutafyan%' OR lower(coalesce(alias, '')) LIKE '%mutafyan%'
   OR lower(coalesce(user_name, '')) LIKE '%kollisa4%' OR lower(coalesce(alias, '')) LIKE '%kollisa4%'
   OR lower(coalesce(user_name, '')) LIKE '%sathwick%' OR lower(coalesce(alias, '')) LIKE '%sathwick%'
   OR lower(coalesce(user_name, '')) LIKE '%kollipara%' OR lower(coalesce(alias, '')) LIKE '%kollipara%'
   OR lower(coalesce(user_name, '')) LIKE '%mohdha1%' OR lower(coalesce(alias, '')) LIKE '%mohdha1%'
   OR lower(coalesce(user_name, '')) LIKE '%hasnain%' OR lower(coalesce(alias, '')) LIKE '%hasnain%'
   OR lower(coalesce(user_name, '')) LIKE '%mohd%' OR lower(coalesce(alias, '')) LIKE '%mohd%'
ORDER BY user_name;

-- COMMAND ----------

-- R12: the four mapped Finance userids (config identity_seed). Every row must show in_profile = true,
--      identity_status = 'Active', has_app = true, at least one keyuser present in t_sd_keyuser_profile,
--      and brand/entity/BU counts matching the mapping document (see config _comment_identity_expected).
--      Any other result means the user resolves to UNMAPPED / NO_ACTIVE_KEYUSER (no data) in the demo.
WITH seed AS (
  SELECT * FROM VALUES ('puranch1@novartis.net', 'ALVARVI6'),
  ('mutafmi1@novartis.net', 'AGARWVAC'),
  ('kollisa4@novartis.net', 'ABADFR1'),
  ('mohdha1@novartis.net', 'ABESH7') AS seed(databricks_user, finance_userid)
),
ku AS (
  SELECT seed.finance_userid, s.keyuser,
         EXISTS (SELECT 1 FROM f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_profile kp WHERE kp.keyuser = s.keyuser) AS keyuser_in_profile
  FROM seed JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_config_t_md_user_settings s ON s.userid = seed.finance_userid
  WHERE s.keyuser IS NOT NULL AND trim(s.keyuser) <> ''
),
ent AS (SELECT ku.finance_userid, COUNT(DISTINCT e.entity) AS n FROM ku JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_entity e ON e.userid = ku.keyuser GROUP BY ku.finance_userid),
brd AS (SELECT ku.finance_userid, COUNT(DISTINCT b.brand) AS n FROM ku JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_brand b ON b.userid = ku.keyuser GROUP BY ku.finance_userid),
bus AS (SELECT ku.finance_userid, COUNT(DISTINCT u.business_unit) AS n FROM ku JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_keyuser_by_business_unit u ON u.userid = ku.keyuser GROUP BY ku.finance_userid),
kl AS (
  SELECT finance_userid, array_join(array_sort(collect_set(keyuser)), ',') AS keyusers,
         bool_and(keyuser_in_profile) AS all_keyusers_in_keyuser_profile
  FROM ku GROUP BY finance_userid
)
SELECT seed.databricks_user, seed.finance_userid,
       p.userid IS NOT NULL AS in_profile, p.user_name, p.identity_status, p.applications,
       array_contains(transform(split(coalesce(p.applications, ''), '[;,]'), x -> upper(trim(x))), 'GENIE2') AS has_app,
       kl.keyusers, kl.all_keyusers_in_keyuser_profile,
       COALESCE(brd.n, 0) AS brands, COALESCE(ent.n, 0) AS entities, COALESCE(bus.n, 0) AS business_units
FROM seed
LEFT JOIN f1common_eu_platform.chandra_fin_genie_poc.src_cur_t_sd_user_profile p ON p.userid = seed.finance_userid
LEFT JOIN kl ON kl.finance_userid = seed.finance_userid
LEFT JOIN ent ON ent.finance_userid = seed.finance_userid
LEFT JOIN brd ON brd.finance_userid = seed.finance_userid
LEFT JOIN bus ON bus.finance_userid = seed.finance_userid
ORDER BY seed.databricks_user;
